
#------------------------------
Pilot study: age-type of jobs
#------------------------------
  
### Data Importing
  
setwd() # set current working directory
getwd()
list.files()

Pilot <- read.csv2("Pilot_AgeTypeJobs.csv",
                   header = TRUE,
                   check.names = FALSE,
                   fileEncoding = "UTF-8-BOM",
                   stringsAsFactors = FALSE)

# drop the 2nd header row 
Pilot <- Pilot[-1, ]

# convert types nicely
Pilot[] <- lapply(Pilot, function(x) type.convert(x, as.is = TRUE))
View(Pilot)


### Data Cleaning

# Exclude participants who did not agree with the informed consent or failed one of the attention checks

Pilot_clean <- subset(Pilot,
                      IC != "niet akkoord ga" &
                        AC_1 == 1 & AC_2 == 9 & AC_3 == 7)

table(Pilot_clean$AC_1, useNA="ifany")
table(Pilot_clean$AC_2, useNA="ifany")
table(Pilot_clean$AC_3, useNA="ifany")

# Compute variables

grep("^Age-type_", names(Pilot_clean), value = TRUE)[1:20]

library(dplyr)
library(tidyr)

Pilot_jobs <- Pilot_clean %>%
  mutate(.id = row_number()) %>%                       # temporary row id (participant)
  pivot_longer(
    cols = matches("^Age-type_[12]_"),
    names_to = c("scale", "item", "job"),
    names_pattern = "^(Age-type)_(\\d+)_(.*)$",
    values_to = "value"
  ) %>%
  mutate(value = as.numeric(value)) %>%
  group_by(.id, job) %>%                               # <- per participant AND job
  summarise(Age_type = mean(value, na.rm = TRUE), .groups = "drop") %>%
  pivot_wider(
    id_cols = .id,
    names_from = job,
    values_from = Age_type,
    names_prefix = "Age_type_"
  )


Pilot_clean <- Pilot_clean %>%
  mutate(.id = row_number()) %>%
  left_join(Pilot_jobs, by = ".id") %>%
  select(-.id)

names(Pilot_clean) <- make.names(names(Pilot_clean), unique = TRUE)

# Check
grep("^Age_type_", names(Pilot_clean), value = TRUE)[1:20]
length(grep("^Age_type_", names(Pilot_clean), value = TRUE))
summary(Pilot_clean$`Age_type_CEO`)

                                 
### Sample Description

#Age
mean_age <- mean(Pilot_clean$Leeftijd, na.rm = TRUE)
sd_age   <- sd(Pilot_clean$Leeftijd, na.rm = TRUE)
mean_age; sd_age

#Gender
table(Pilot_clean$Geslacht, useNA = "ifany")
pct_women <- 100 * mean(Pilot_clean$Geslacht == "Vrouw", na.rm = TRUE)
pct_women

#Diploma
table(Pilot_clean$Diploma, useNA = "ifany")
pct_bach_or_master <- 100 * mean(
  Pilot_clean$Diploma %in% c("Hoger onderwijs: academische bachelor", "Hoger onderwijs: master"),
  na.rm = TRUE)
pct_bach_or_master

#Ethnicity
table(Pilot_clean$Etniciteit, useNA = "ifany")
pct_westeur <- 100 * mean(Pilot_clean$Etniciteit == "West-Europees", na.rm = TRUE)
pct_westeur

### Age-type of jobs

# Descriptive
age_cols <- grep("^Age_type_", names(Pilot_clean), value = TRUE)

age_type_desc <- data.frame(
  job  = sub("^Age_type_", "", age_cols),
  mean = sapply(Pilot_clean[age_cols], mean, na.rm = TRUE),
  sd   = sapply(Pilot_clean[age_cols], sd,   na.rm = TRUE),
  n    = sapply(Pilot_clean[age_cols], function(x) sum(!is.na(x)))
)

age_type_desc <- age_type_desc[order(age_type_desc$mean), ]  # low -> high
age_type_desc

# One-sample t-tests vs mean of scale (i.e., age neutral = 5)
t.test(Pilot_clean$Age_type_Bibliothecaris, mu = 5)

t.test(Pilot_clean$Age_type_Pensioenadviseur, mu = 5)

t.test(Pilot_clean$Age_type_Sociale.media.specialist, mu = 5)

t.test(Pilot_clean$Age_type_Grafisch.ontwerper, mu = 5)


### Gender-type of jobs
gender_cols <- grep("^Gender.type_", names(Pilot_clean), value = TRUE)

gender_type_desc <- data.frame(
  job  = sub("^Gender.type_", "", gender_cols),
  mean = sapply(Pilot_clean[gender_cols], function(x) mean(as.numeric(x), na.rm = TRUE)),
  sd   = sapply(Pilot_clean[gender_cols], function(x) sd(as.numeric(x),   na.rm = TRUE)),
  n    = sapply(Pilot_clean[gender_cols], function(x) sum(!is.na(as.numeric(x))))
)

gender_type_desc <- gender_type_desc[order(gender_type_desc$mean), ]
gender_type_desc



