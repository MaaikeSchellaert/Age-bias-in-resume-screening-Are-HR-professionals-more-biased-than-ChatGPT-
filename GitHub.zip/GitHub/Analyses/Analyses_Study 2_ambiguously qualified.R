# ================================================================
# Analyses Study 2: AMBIGUOUS APPLICANTS (between-subjects)
# ================================================================

# =================
# HR professionals
# =================

#------------------
### Data Importing
#------------------

setwd() # set current working directory
getwd()
list.files()


HR_ambigu_uncleaned <- read.csv2("Data HRprofessionals_between-subjects_Ambigue_completes_uncleaned.csv",
                   header = TRUE,
                   check.names = FALSE,
                   fileEncoding = "UTF-8-BOM",
                   stringsAsFactors = FALSE)

# drop the 2nd header row 
HR_ambigu_uncleaned <- HR_ambigu_uncleaned[-1, ]

# convert types nicely
HR_ambigu_uncleaned[] <- lapply(HR_ambigu_uncleaned, function(x) type.convert(x, as.is = TRUE))
View(HR_ambigu_uncleaned)

str(HR_ambigu_uncleaned$Leeftijd)
str(HR_ambigu_uncleaned$HR_Erv)

#-----------------
### Data Cleaning
#-----------------

# Exclude participants who:
# did not agree with the informed consent,
# or had 0 years of experience in HR,
# or had no experience with resume screening, 
# or failed the attention check
# or had an unrealistic years of HR experience
# or were older than 67y

HR_ambigu <- subset(HR_ambigu_uncleaned,
                     IC != "niet akkoord ga" &
                     HR_Erv != 0 &
                     Cv_Erv == "Ja" &
                     QualCheck == "Niet akkoord" &
                     HR_Erv <= (Leeftijd - 16) &
                     Leeftijd < 68)

View(HR_ambigu)
nrow(HR_ambigu)

#----------------------
### Sample Description
#----------------------

#HR experience
mean_HRexp <- mean(HR_ambigu$HR_Erv, na.rm = TRUE)
sd_HRexp   <- sd(HR_ambigu$HR_Erv, na.rm = TRUE)
mean_HRexp; sd_HRexp

#Age
mean_age <- mean(HR_ambigu$Leeftijd, na.rm = TRUE)
sd_age   <- sd(HR_ambigu$Leeftijd, na.rm = TRUE)
mean_age; sd_age

#Gender
table(HR_ambigu$Geslacht, useNA = "ifany")
pct_women <- 100 * mean(HR_ambigu$Geslacht == "Vrouw", na.rm = TRUE)
pct_women

#Ethnicity
table(HR_ambigu$Etniciteit, useNA = "ifany")
pct_westeur <- 100 * mean(HR_ambigu$Etniciteit == "West-Europees", na.rm = TRUE)
pct_westeur

#Diploma
table(HR_ambigu$Diploma, useNA = "ifany")
pct_bach_or_master <- 100 * mean(
  HR_ambigu$Diploma %in% c("Hoger onderwijs: master"),
  na.rm = TRUE)
pct_bach_or_master


head(HR_ambigu, 1)

# ========
# ChatGPT
# ========

#------------------
# Data Importing
#------------------

setwd() # set current working directory
getwd()
list.files()

GPT_ambigu <- read.csv("study2_ambiguous_between.csv",header = TRUE)
View(GPT_ambigu)

head(GPT_ambigu, 1)

# =============================================================================
# Clean & merge HR and ChatGPT datasets for the age x gender x job-type study
# =============================================================================
# Inputs 
#   - HR_ambigu  : wide-format HR professionals dataset
#   - GPT_ambigu : long-format ChatGPT dataset
# Output:
#   - combined_ambigu : merged analysis-ready dataset
# =============================================================================

library(tidyverse)


# -----------------------------------------------------------------------------
# 0. Inspect raw datasets
# -----------------------------------------------------------------------------
cat("\n========== RAW HR_ambigu ==========\n")
print(head(HR_ambigu, 2))
cat("\n--- str(HR_ambigu) ---\n")
str(HR_ambigu)

cat("\n========== RAW GPT_ambigu ==========\n")
print(head(GPT_ambigu, 2))
cat("\n--- str(GPT_ambigu) ---\n")
str(GPT_ambigu)


# -----------------------------------------------------------------------------
# 1. Lookup tables (shared by both datasets)
# -----------------------------------------------------------------------------
job_means <- tibble(
  JobTitle = c("Social Media Specialist", "Grafisch Ontwerper",
               "Pensioenadviseur",        "Bibliothecaris"),
  JobGenderMean = c(4.8333, 4.0741, 3.3148, 4.9444)
)

job_gender_cat <- tibble(
  JobTitle = c("Social Media Specialist", "Grafisch Ontwerper",
               "Pensioenadviseur",        "Bibliothecaris"),
  JobGenderCat = c("female", "neutral", "male", "female")
)


# -----------------------------------------------------------------------------
# 2. Clean HR dataset
# -----------------------------------------------------------------------------
# The 16 condition columns follow the pattern Age[Y/O]_Job[Y/O]_[M/F]_[A/B]_<n>
# where <n> is a meaningless Qualtrics suffix.

condition_cols <- grep("^Age[YO]_Job[YO]_[MF]_[AB]_\\d+$",
                       names(HR_ambigu), value = TRUE)

cat("\nDetected", length(condition_cols), "condition columns in HR_ambigu.\n")
if (length(condition_cols) != 16) {
  warning("Expected 16 condition columns but found ", length(condition_cols),
          ". Check column-name pattern.")
}

# --- Social Desirability scale (HR only) ---------------------------------
# 13 items (SD1-SD13), binary "Waar"/"Niet waar" responses.
# Reverse-score SD5, SD7, SD9, SD10, SD13.
# Final SD_mean = rowmean of all 13 items (after reversing), range 0-1.
sd_items         <- paste0("SD", 1:13)
sd_reverse_items <- c("SD5", "SD7", "SD9", "SD10", "SD13")

missing_sd <- setdiff(sd_items, names(HR_ambigu))
if (length(missing_sd) > 0) {
  warning("Missing SD items in HR_ambigu: ", paste(missing_sd, collapse = ", "))
}

# Inspect raw response values once so coding mismatches surface here, not silently
cat("\nUnique values in SD items (HR raw):\n")
print(unique(unlist(HR_ambigu[, intersect(sd_items, names(HR_ambigu))])))

HR_ambigu <- HR_ambigu %>%
  # 1. Convert all SD items to 0/1 numeric
  mutate(across(all_of(intersect(sd_items, names(HR_ambigu))),
                ~ case_when(
                  . == "Waar"      ~ 1L,
                  . == "Niet waar" ~ 0L,
                  TRUE             ~ NA_integer_
                ))) %>%
  # 2. Reverse-score the specified items (1 - x on the 0/1 scale)
  mutate(across(all_of(intersect(sd_reverse_items, names(HR_ambigu))),
                ~ 1L - .)) %>%
  # 3. Compute the composite as the rowmean across all 13 items
  mutate(SD_mean = rowMeans(across(all_of(intersect(sd_items, names(.)))),
                            na.rm = TRUE))

cat("\nSD_mean summary (HR):\n")
print(summary(HR_ambigu$SD_mean))

HR_clean <- HR_ambigu %>%
  # add a participant id so we can keep track
  mutate(ParticipantID = paste0("HR_", row_number())) %>%
  pivot_longer(
    cols      = all_of(condition_cols),
    names_to  = "Condition",
    values_to = "Suitability"
  ) %>%
  filter(!is.na(Suitability)) %>%
  # parse the condition string
  mutate(
    ApplicantAge    = if_else(str_detect(Condition, "^AgeY"), "Jong", "Oud"),
    JobAge          = if_else(str_detect(Condition, "_JobY_"), "Jong", "Oud"),
    ApplicantGender = if_else(str_detect(Condition, "_M_"),    "Man",  "Vrouw"),
    ProfileVersion  = str_extract(Condition, "(?<=_)[AB](?=_\\d+$)")
  ) %>%
  mutate(
    JobTitle = case_when(
      JobAge == "Jong" & ProfileVersion == "A" ~ "Social Media Specialist",
      JobAge == "Jong" & ProfileVersion == "B" ~ "Grafisch Ontwerper",
      JobAge == "Oud"  & ProfileVersion == "A" ~ "Bibliothecaris",
      JobAge == "Oud"  & ProfileVersion == "B" ~ "Pensioenadviseur",
      TRUE ~ NA_character_
    )
  ) %>%
  left_join(job_means,      by = "JobTitle") %>%
  left_join(job_gender_cat, by = "JobTitle") %>%
  mutate(
    JobGenderCat = factor(JobGenderCat, levels = c("male", "neutral", "female")),
    Rater       = "HR",
    Suitability  = as.numeric(Suitability)
  ) %>%
  # keep only what we need: covariates + analysis vars
  select(
    ParticipantID, Rater, Suitability,
    ApplicantAge, JobAge, ApplicantGender, ProfileVersion,
    JobTitle, JobGenderMean, JobGenderCat,
    # HR-only covariates
    Leeftijd, Geslacht, Diploma, Etniciteit,
    HR_Erv, Cv_Erv, TijdPers, Functie,
    SD_mean
  )

# Sanity check: every participant should appear exactly once
n_pp_hr <- n_distinct(HR_clean$ParticipantID)
n_rows_hr <- nrow(HR_clean)
cat("\nHR: rows =", n_rows_hr, "| unique participants =", n_pp_hr, "\n")
if (n_rows_hr != n_pp_hr) {
  warning("Some HR participants have more than one non-NA condition rating.")
}


# -----------------------------------------------------------------------------
# 3. Clean GPT dataset
# -----------------------------------------------------------------------------
# Helper: collapse whitespace and lowercase for fuzzy job-title matching
norm_title <- function(x) tolower(str_squish(x))

GPT_clean <- GPT_ambigu %>%
  rename(
    Suitability         = gpt54,
    Suitability_gpt4o   = gpt4o,
    Suitability_gpt41   = gpt41
  ) %>%
  mutate(
    ApplicantAge    = case_when(
      str_detect(conditie, "AgeYoung") ~ "Jong",
      str_detect(conditie, "AgeOld")   ~ "Oud",
      TRUE ~ NA_character_
    ),
    JobAge = case_when(
      str_detect(conditie, "JobYoung") ~ "Jong",
      str_detect(conditie, "JobOld")   ~ "Oud",
      TRUE ~ NA_character_
    ),
    ApplicantGender = case_when(
      str_detect(conditie, "Male")   ~ "Man",
      str_detect(conditie, "Female") ~ "Vrouw",
      TRUE ~ NA_character_
    ),
    # Derive JobTitle from jobtitel_job (most reliable signal),
    # mapping the GPT-side titles to our canonical Dutch labels.
    job_norm = norm_title(jobtitel_job),
    JobTitle = case_when(
      str_detect(job_norm, "social media")            ~ "Social Media Specialist",
      str_detect(job_norm, "graf")                    ~ "Grafisch Ontwerper",
      str_detect(job_norm, "biblio|librar")           ~ "Bibliothecaris",
      str_detect(job_norm, "pensio|retire")           ~ "Pensioenadviseur",
      TRUE ~ NA_character_
    ),
    # ProfileVersion is implied by (JobAge + JobTitle).
    ProfileVersion = case_when(
      JobTitle == "Social Media Specialist" ~ "A",
      JobTitle == "Grafisch Ontwerper"      ~ "B",
      JobTitle == "Bibliothecaris"          ~ "A",
      JobTitle == "Pensioenadviseur"        ~ "B",
      TRUE ~ NA_character_
    )
  ) %>%
  left_join(job_means,      by = "JobTitle") %>%
  left_join(job_gender_cat, by = "JobTitle") %>%
  mutate(
    JobGenderCat       = factor(JobGenderCat, levels = c("male", "neutral", "female")),
    Rater             = "GPT",
    Suitability        = as.numeric(Suitability),
    Suitability_gpt4o  = as.numeric(Suitability_gpt4o),
    Suitability_gpt41  = as.numeric(Suitability_gpt41),
    ParticipantID      = paste0("GPT_", row_number())
  )

# --- Cross-check ProfileVersion against job_id, if job_id looks informative ---
cat("\nGPT job_id ↔ JobTitle cross-tab (verify ProfileVersion mapping):\n")
print(GPT_clean %>% count(job_id, JobTitle, ProfileVersion))

# --- Cross-check raw leeftijd vs derived ApplicantAge ---
if ("leeftijd" %in% names(GPT_clean)) {
  age_mismatch <- GPT_clean %>%
    mutate(leeftijd_norm = case_when(
      tolower(leeftijd) %in% c("jong", "young") ~ "Jong",
      tolower(leeftijd) %in% c("oud", "old")    ~ "Oud",
      TRUE ~ NA_character_
    )) %>%
    filter(leeftijd_norm != ApplicantAge)
  if (nrow(age_mismatch) > 0) {
    warning("GPT: ", nrow(age_mismatch),
            " rows where raw 'leeftijd' disagrees with derived ApplicantAge.")
    print(age_mismatch %>% select(ParticipantID, conditie, leeftijd, ApplicantAge))
  } else {
    cat("\nGPT: raw 'leeftijd' agrees with derived ApplicantAge in all rows.\n")
  }
}

# Keep only what we need for the merge
GPT_clean <- GPT_clean %>%
  select(
    ParticipantID, Rater, Suitability,
    Suitability_gpt4o, Suitability_gpt41,
    ApplicantAge, JobAge, ApplicantGender, ProfileVersion,
    JobTitle, JobGenderMean, JobGenderCat
  )


# -----------------------------------------------------------------------------
# 4. VERIFICATION STEP — compare cleaned datasets before merging
# -----------------------------------------------------------------------------
cat("\n\n========== VERIFICATION: cleaned HR_clean ==========\n")
str(HR_clean)

cat("\n========== VERIFICATION: cleaned GPT_clean ==========\n")
str(GPT_clean)

shared_cat_vars <- c("ApplicantAge", "JobAge", "ApplicantGender",
                     "ProfileVersion", "JobTitle", "JobGenderCat")

cat("\n--- Unique values & frequencies for shared categorical variables ---\n")
for (v in shared_cat_vars) {
  cat("\n## Variable:", v, "##\n")
  cat("HR  unique :", paste(sort(unique(as.character(HR_clean[[v]]))),  collapse = " | "), "\n")
  cat("GPT unique :", paste(sort(unique(as.character(GPT_clean[[v]]))), collapse = " | "), "\n")
  
  hr_set  <- sort(unique(as.character(HR_clean[[v]])))
  gpt_set <- sort(unique(as.character(GPT_clean[[v]])))
  if (!identical(hr_set, gpt_set)) {
    warning("Mismatch in unique values for '", v, "':\n",
            "  Only in HR : ", paste(setdiff(hr_set, gpt_set), collapse = ", "), "\n",
            "  Only in GPT: ", paste(setdiff(gpt_set, hr_set), collapse = ", "))
  } else {
    cat("OK — value sets match.\n")
  }
  
  cat("HR table:\n");  print(table(HR_clean[[v]],  useNA = "ifany"))
  cat("GPT table:\n"); print(table(GPT_clean[[v]], useNA = "ifany"))
}

cat("\n--- Numeric variables: class / range / summary ---\n")
num_vars_hr  <- c("Suitability", "JobGenderMean")
num_vars_gpt <- c("Suitability", "Suitability_gpt4o", "Suitability_gpt41", "JobGenderMean")

for (v in num_vars_hr) {
  cat("\nHR  ", v, "— class:", class(HR_clean[[v]]),
      "| range:", paste(range(HR_clean[[v]], na.rm = TRUE), collapse = " – "), "\n")
  print(summary(HR_clean[[v]]))
}
for (v in num_vars_gpt) {
  cat("\nGPT ", v, "— class:", class(GPT_clean[[v]]),
      "| range:", paste(range(GPT_clean[[v]], na.rm = TRUE), collapse = " – "), "\n")
  print(summary(GPT_clean[[v]]))
}

cat("\n--- Cross-check: JobTitle ↔ JobAge / ProfileVersion / JobGenderMean / JobGenderCat ---\n")
cat("\nHR:\n")
print(HR_clean %>%
        distinct(JobTitle, JobAge, ProfileVersion, JobGenderMean, JobGenderCat) %>%
        arrange(JobAge, ProfileVersion))
cat("\nGPT:\n")
print(GPT_clean %>%
        distinct(JobTitle, JobAge, ProfileVersion, JobGenderMean, JobGenderCat) %>%
        arrange(JobAge, ProfileVersion))

# Compare types of shared columns
shared_all <- c("Rater", "Suitability", "ApplicantAge", "JobAge",
                "ApplicantGender", "ProfileVersion", "JobTitle",
                "JobGenderMean", "JobGenderCat")
type_compare <- tibble(
  variable = shared_all,
  HR_type  = sapply(shared_all, function(v) class(HR_clean[[v]])[1]),
  GPT_type = sapply(shared_all, function(v) class(GPT_clean[[v]])[1])
) %>%
  mutate(match = HR_type == GPT_type)
cat("\n--- Type comparison for shared analysis columns ---\n")
print(type_compare)
if (any(!type_compare$match)) {
  warning("Type mismatches detected — fix before merging:\n",
          paste(capture.output(print(type_compare %>% filter(!match))), collapse = "\n"))
}


# -----------------------------------------------------------------------------
# 5. MERGE
# -----------------------------------------------------------------------------
combined_ambigu <- bind_rows(HR_clean, GPT_clean) %>%
  mutate(
    ApplicantAge    = factor(ApplicantAge,    levels = c("Jong", "Oud")),
    JobAge          = factor(JobAge,          levels = c("Jong", "Oud")),
    ApplicantGender = factor(ApplicantGender, levels = c("Man", "Vrouw")),
    ProfileVersion  = factor(ProfileVersion,  levels = c("A", "B")),
    Rater          = factor(Rater,          levels = c("HR", "GPT"))
  )


# -----------------------------------------------------------------------------
# 6. FINAL CHECKS
# -----------------------------------------------------------------------------
cat("\n\n========== FINAL CHECKS ==========\n")
cat("\nRows per Rater:\n")
print(combined_ambigu %>% count(Rater))
cat("\nTotal rows:", nrow(combined_ambigu), "\n")

cat("\nCell counts by Rater × ApplicantAge × JobAge × ApplicantGender × ProfileVersion:\n")
print(combined_ambigu %>%
        count(Rater, ApplicantAge, JobAge, ApplicantGender, ProfileVersion) %>%
        arrange(Rater, ApplicantAge, JobAge, ApplicantGender, ProfileVersion),
      n = Inf)

cat("\nNAs in core analysis columns:\n")
core_vars <- c("Suitability", "ApplicantAge", "JobAge",
               "ApplicantGender", "ProfileVersion",
               "JobTitle", "JobGenderMean", "JobGenderCat", "Rater")
na_report <- combined_ambigu %>%
  summarise(across(all_of(core_vars), ~sum(is.na(.)))) %>%
  pivot_longer(everything(), names_to = "variable", values_to = "n_NA")
print(na_report)
if (any(na_report$n_NA > 0)) {
  warning("Unexpected NAs in core variables — see table above.")
}

cat("\nClass of Suitability:", class(combined_ambigu$Suitability), "\n")
if (!is.numeric(combined_ambigu$Suitability)) {
  warning("Suitability is not numeric — fix before analysis.")
}

cat("\nDone. The cleaned, merged dataset is in `combined_ambigu`.\n")



# =============================================================================
# Descriptives, reliability (KR-20), and correlations - HR professionals
# =============================================================================
#   - combined_ambigu  : merged dataset from the cleaning script
#   - HR_ambigu        : HR dataset AFTER cleaning script ran
#                          (SD items recoded to 0/1, reversals applied)
# =============================================================================

library(tidyverse)
library(psych)


install.packages("flextable")
library(flextable)

# -----------------------------------------------------------------------------
# 1. Subset to HR participants
# -----------------------------------------------------------------------------
install.packages("dplyr")
library(dplyr)

HR_only <- combined_ambigu %>%
  filter(Rater == "HR") %>%
  mutate(
    Leeftijd = suppressWarnings(as.numeric(as.character(Leeftijd))),
    HR_Erv   = suppressWarnings(as.numeric(as.character(HR_Erv)))
  )

cat("HR participants:", nrow(HR_only), "\n")


# -----------------------------------------------------------------------------
# 2. Inspect raw values for the categorical variables we need to recode
# -----------------------------------------------------------------------------
cat("\n========== UNIQUE VALUES (check before recoding) ==========\n")

cat("\n--- Etniciteit ---\n")
print(HR_only %>% count(Etniciteit))

cat("\n--- Diploma ---\n")
print(HR_only %>% count(Diploma))

cat("\n--- Geslacht ---\n")
print(HR_only %>% count(Geslacht))


# -----------------------------------------------------------------------------
# 3. Recode categorical variables to ordinal/binary for correlations
# -----------------------------------------------------------------------------

library(dplyr)

HR_only <- HR_only %>%
  mutate(
    Ethnicity_bin = case_when(
      Etniciteit == "West-Europees" ~ 1L,
      is.na(Etniciteit)              ~ NA_integer_,
      TRUE                           ~ 0L
    ),
    # Education: exact labels from the Qualtrics survey.
    # Scale: 0 = primary, 1 = secondary, 2 = professional bachelor,
    # 3 = academic bachelor, 4 = master, 5 = doctoral, 6 = not specified.
    Education_ord = case_when(
      Diploma == "Basisonderwijs (basisschool)"                ~ 0L,
      Diploma == "Secundair onderwijs (middelbaar)"            ~ 1L,
      Diploma == "Hoger onderwijs: professionele bachelor"     ~ 2L,
      Diploma == "Hoger onderwijs: academische bachelor"       ~ 3L,
      Diploma == "Hoger onderwijs: master"                     ~ 4L,
      Diploma == "Hoger onderwijs: doctoraat"                  ~ 5L,
      Diploma == "Anders, gelieve dit te specifiëren:"         ~ 6L,
      TRUE                                                     ~ NA_integer_
    )
  )

# Diagnostic: did the recoding catch everything?
cat("\n--- Recoded Ethnicity_bin (0 = non-West-Eur, 1 = West-Eur) ---\n")
print(HR_only %>% count(Etniciteit, Ethnicity_bin))

cat("\n--- Recoded Education_ord (0 = primary, 5 = doctoral, 6 = not specified) ---\n")
print(HR_only %>% count(Diploma, Education_ord))

unmatched_eth <- HR_only %>% filter(!is.na(Etniciteit) & is.na(Ethnicity_bin))
if (nrow(unmatched_eth) > 0) {
  warning(nrow(unmatched_eth),
          " Etniciteit values did not match any category - check the printout above.")
}
unmatched_edu <- HR_only %>% filter(!is.na(Diploma) & is.na(Education_ord))
if (nrow(unmatched_edu) > 0) {
  warning(nrow(unmatched_edu),
          " Diploma values did not match any category - edit the case_when() above.")
}


# -----------------------------------------------------------------------------
# 4. Descriptive statistics - all study variables
# -----------------------------------------------------------------------------
cat("\n========== DESCRIPTIVES ==========\n")

# Continuous + ordinal/binary numeric versions: M, SD via psych::describe
desc_tbl <- HR_only %>%
  transmute(
    Age            = Leeftijd,
    Gender         = case_when(Geslacht == "Man" ~ 0L,
                               Geslacht == "Vrouw" ~ 1L,
                               TRUE ~ NA_integer_),
    Ethnicity      = Ethnicity_bin,
    Education      = ifelse(Education_ord == 6L, NA_integer_, Education_ord),
    HR_Experience  = HR_Erv,
    SocialDesir    = SD_mean,
    Suitability    = Suitability
  )

cat("\n--- Means / SDs (Gender, Ethnicity coded 0/1 - 'mean' = proportion at 1) ---\n")
print(psych::describe(desc_tbl, quant = c(.25, .75))[, c("n", "mean", "sd", "min",
                                                         "max", "skew", "kurtosis")],
      digits = 3)

cat("\n--- Frequency tables (raw labels) ---\n")
cat("\nGender:\n");    print(HR_only %>% count(Geslacht)   %>% mutate(pct = round(100 * n / sum(n), 1)))
cat("\nEthnicity:\n"); print(HR_only %>% count(Etniciteit) %>% mutate(pct = round(100 * n / sum(n), 1)))
cat("\nEducation:\n"); print(HR_only %>% count(Diploma)    %>% mutate(pct = round(100 * n / sum(n), 1)))


## Scale use

summary(GPT_ambigu$gpt54)
table(GPT_ambigu$gpt54)
prop.table(table(GPT_ambigu$gpt54)) * 100


# Alleen HR-raters selecteren
HR_only_ambigu <- combined_ambigu %>%
  filter(Rater == "HR")

# Descriptives
summary(HR_only_ambigu$Suitability)

# Frequentie per score
table(HR_only_ambigu$Suitability)

# Percentage per score
prop.table(table(HR_only_ambigu$Suitability)) * 100

HR_only_ambigu %>%
  summarise(
    n = n(),
    ending_0 = mean(Suitability %% 10 == 0) * 100,
    ending_5 = mean(Suitability %% 10 == 5) * 100,
    ending_0_or_5 = mean(Suitability %% 5 == 0) * 100
  )

GPT_ambigu %>%
  summarise(
    n = n(),
    ending_0 = mean(gpt54 %% 10 == 0) * 100,
    ending_5 = mean(gpt54 %% 10 == 5) * 100,
    ending_0_or_5 = mean(gpt54 %% 5 == 0) * 100

# -----------------------------------------------------------------------------
# 5. Reliability for Social Desirability (KR-20)
# -----------------------------------------------------------------------------
# SD items are binary (0/1) and already reverse-scored in HR_ambigu.
# Cronbach's alpha on dichotomous items is mathematically identical to KR-20.
# We use psych::alpha() and label its output as KR-20.

cat("\n========== RELIABILITY: KR-20 FOR SOCIAL DESIRABILITY ==========\n")

sd_items <- paste0("SD", 1:13)

sd_item_data <- HR_ambigu %>%
  select(all_of(intersect(sd_items, names(HR_ambigu)))) %>%
  mutate(across(everything(), as.numeric))

cat("Items used:", ncol(sd_item_data),
    "| n participants:", nrow(sd_item_data), "\n")

zero_var_items <- names(sd_item_data)[sapply(sd_item_data, function(x) {
  v <- var(x, na.rm = TRUE)
  is.na(v) || v == 0
})]
if (length(zero_var_items) > 0) {
  warning("Items with zero/NA variance (will distort KR-20): ",
          paste(zero_var_items, collapse = ", "))
}

kr20_result <- psych::alpha(sd_item_data,
                            check.keys = FALSE, # items already reversed, so don't reverse again
                            warnings   = TRUE)

cat("\nKR-20 (= Cronbach's alpha for binary items):",
    round(kr20_result$total$raw_alpha, 3), "\n")

ci_lower <- suppressWarnings(as.numeric(unlist(kr20_result$feldt$lower.ci))[1])
ci_upper <- suppressWarnings(as.numeric(unlist(kr20_result$feldt$upper.ci))[1])

if (is.finite(ci_lower) && is.finite(ci_upper)) {
  cat(sprintf("95%% CI (Feldt): [%.3f, %.3f]\n", ci_lower, ci_upper))
} else {
  ase <- suppressWarnings(as.numeric(kr20_result$total$ase))
  if (is.finite(ase)) {
    cat(sprintf("95%% CI (normal approx.): [%.3f, %.3f]\n",
                as.numeric(kr20_result$total$raw_alpha) - 1.96 * ase,
                as.numeric(kr20_result$total$raw_alpha) + 1.96 * ase))
  } else {
    cat("(CI not available)\n")
  }
}

cat("\n--- Full output (item statistics, KR-20 if item dropped, etc.) ---\n")
print(kr20_result$total,      digits = 3)
cat("\nItem statistics:\n")
print(kr20_result$item.stats, digits = 3)
cat("\nKR-20 if item dropped:\n")
print(kr20_result$alpha.drop, digits = 3)


# -----------------------------------------------------------------------------
# 6. Correlation matrix
# -----------------------------------------------------------------------------
cat("\n========== CORRELATIONS ==========\n")
cat("Coding for matrix:\n")
cat("  Gender    : 0 = Man, 1 = Vrouw\n")
cat("  Ethnicity : 0 = non-West-European, 1 = West-European\n")
cat("  Education : 0 = primary school ... 5 = doctoral (6 = NA)\n\n")

cor_result <- psych::corr.test(desc_tbl, use = "pairwise", adjust = "none")

cat("--- r ---\n")
print(round(cor_result$r, 3))

cat("\n--- p-values ---\n")
print(round(cor_result$p, 3))

cat("\n--- pairwise n ---\n")
print(cor_result$n)

# APA-style table: r with significance stars, below diagonal
sig_stars <- function(p) {
  case_when(
    is.na(p) ~ "",
    p < .001 ~ "***",
    p < .01  ~ "**",
    p < .05  ~ "*",
    TRUE     ~ ""
  )
}

r_mat <- cor_result$r
p_mat <- cor_result$p
apa_mat <- matrix("", nrow = nrow(r_mat), ncol = ncol(r_mat),
                  dimnames = dimnames(r_mat))
for (i in seq_len(nrow(r_mat))) {
  for (j in seq_len(ncol(r_mat))) {
    if (i < j) {
      apa_mat[i, j] <- paste0(sprintf("%.2f", r_mat[i, j]),
                              sig_stars(p_mat[i, j]))
    } else if (i == j) {
      apa_mat[i, j] <- "-"
    }
  }
}

cat("\n--- APA-style correlation table ---\n")
cat("* p<.05, ** p<.01, *** p<.001\n\n")
print(noquote(apa_mat))


# -----------------------------------------------------------------------------
# 7. Compact APA-style summary table (M, SD, reliability, correlations)
# -----------------------------------------------------------------------------
cat("\n========== APA-STYLE SUMMARY TABLE ==========\n")

means <- sapply(desc_tbl, mean, na.rm = TRUE)
sds   <- sapply(desc_tbl, sd,   na.rm = TRUE)
ns    <- sapply(desc_tbl, function(x) sum(!is.na(x)))

reliability_vec <- rep(NA_real_, length(means))
names(reliability_vec) <- names(means)
reliability_vec["SocialDesir"] <- round(kr20_result$total$raw_alpha, 3)

summary_tbl <- tibble(
  Variable    = names(means),
  n           = ns,
  M           = round(means, 2),
  SD          = round(sds,   2),
  Reliability = reliability_vec
)
# Append the lower-triangle correlations as numbered columns
for (j in seq_len(ncol(r_mat))) {
  summary_tbl[[as.character(j)]] <- apa_mat[, j]
}

print(summary_tbl)

cat("\nNotes:\n")
cat(" - Reliability for SocialDesir is KR-20.\n")
cat(" - Gender M = proportion Vrouw; Ethnicity M = proportion West-European.\n")
cat(" - Education uses 0-5 ordinal scale; 'not specified' (6) treated as NA.\n")
cat(" - Suitability = job suitability rating (DV).\n")
cat("Done.\n")

# overview of means and sd's per condition

combined_ambigu %>%
  group_by(Rater, ApplicantAge, ApplicantGender, JobAge) %>%
  summarise(
    n  = n(),
    M  = round(mean(Suitability, na.rm = TRUE), 2),
    SD = round(sd(Suitability,   na.rm = TRUE), 2),
    .groups = "drop"
  ) %>%
  arrange(Rater, ApplicantAge, ApplicantGender, JobAge) %>%
  flextable() %>%
  autofit() %>%
  theme_booktabs() %>%
  save_as_docx(path = "descriptives_per_condition.docx")


# marginal mean + SD for chatGPT ratings

combined_ambigu %>%
  filter(Rater == "GPT") %>%
  summarise(
    across(c(Suitability, Suitability_gpt4o, Suitability_gpt41),
           list(M = ~mean(.x, na.rm = TRUE),
                SD = ~sd(.x,   na.rm = TRUE)),
           .names = "{.col}_{.fn}")
  )


# =============================================================================
# Distributional diagnostics for ChatGPT-5.4 (Suitability, 1-100)
# Dataset: combined_ambigu  (built in the cleaning/merge script)
#
# Produces:
#   1. M and SD by condition (+ marginals by each manipulated factor)
#   2. Floor/ceiling frequency by condition (exact boundary + near-boundary band)
#   3. An APA-conform density figure (PNG + PDF, 300 dpi)
# =============================================================================

# ----- 0. Setup --------------------------------------------------------------
install.packages(c("tidyverse", "scales"))   # if needed
library(tidyverse)
library(scales)   # label_percent()

# ---- Config (change these, not the code below) ----
RATER_Rater   <- "GPT"   # "GPT" = ChatGPT-5.4. Set to "HR" or "BOTH" to compare.
SCALE_MIN      <- 1       # lower bound of the Suitability scale
SCALE_MAX      <- 100     # upper bound
NEAR_BAND      <- 5       # "near floor" = <= MIN+band, "near ceiling" = >= MAX-band
OUT_DIR        <- "."     # where figures/tables are written (relative path)
FIG_W          <- 7.5     # figure width in inches
FIG_H          <- 6.0     # figure height in inches

# Guard: make sure the data is actually loaded before anything runs.
if (!exists("combined_ambigu")) {
  stop("`combined_ambigu` not found. Rater your cleaning/merge script first.")
}

# Optional: confirm the columns we rely on exist, fail loudly if not.
need <- c("Rater", "Suitability", "ApplicantAge", "ApplicantGender", "JobAge")
missing <- setdiff(need, names(combined_ambigu))
if (length(missing) > 0) {
  stop("Missing expected column(s): ", paste(missing, collapse = ", "),
       "\nAvailable: ", paste(names(combined_ambigu), collapse = ", "))
}


# ----- 1. Subset and build the condition variable ---------------------------
library(dplyr)
dx <- combined_ambigu %>%
  filter(if (RATER_Rater == "BOTH") TRUE
         else as.character(Rater) == RATER_Rater) %>%
  mutate(
    Suitability     = as.numeric(Suitability),
    ApplicantAge    = factor(ApplicantAge,    levels = c("Jong", "Oud")),
    ApplicantGender = factor(ApplicantGender, levels = c("Man", "Vrouw")),
    JobAge          = factor(JobAge,          levels = c("Jong", "Oud")),
    # 8-cell design condition, ordered so panels read predictably
    Condition = interaction(ApplicantAge, ApplicantGender, JobAge,
                            drop = TRUE, sep = " | ")
  ) %>%
  filter(!is.na(Suitability))

cat("\nRater Rater analysed:", RATER_Rater,
    "| N rows:", nrow(dx),
    "| N conditions:", nlevels(droplevels(dx$Condition)), "\n")


# ----- 2. M and SD by condition ----------------------------------------------
# Per-cell descriptives. n is printed so you can see which cells are thin.
desc_by_condition <- dx %>%
  group_by(ApplicantAge, ApplicantGender, JobAge, Condition) %>%
  summarise(
    n      = sum(!is.na(Suitability)),
    M      = mean(Suitability,   na.rm = TRUE),
    SD     = sd(Suitability,     na.rm = TRUE),
    Median = median(Suitability, na.rm = TRUE),
    Min    = min(Suitability,    na.rm = TRUE),
    Max    = max(Suitability,    na.rm = TRUE),
    Skew   = {                              # base-R skewness, no extra package
      x <- Suitability[!is.na(Suitability)]
      m <- mean(x); s <- sd(x)
      if (s == 0 | length(x) < 3) NA_real_ else mean(((x - m) / s)^3)
    },
    .groups = "drop"
  ) %>%
  arrange(ApplicantAge, ApplicantGender, JobAge)

cat("\n================ M (SD) by condition ================\n")
print(desc_by_condition %>% mutate(across(c(M, SD, Median, Skew), ~round(.x, 2))),
      n = Inf)

# Marginal descriptives by each manipulated factor (useful sanity check)

install.packages("purrr")
library(purrr)

marginals <- map_dfr(
  c("ApplicantAge", "ApplicantGender", "JobAge"),
  function(f) {
    dx %>%
      group_by(Level = .data[[f]]) %>%
      summarise(n = n(),
                M  = mean(Suitability, na.rm = TRUE),
                SD = sd(Suitability,   na.rm = TRUE),
                .groups = "drop") %>%
      mutate(Factor = f, .before = 1)
  }
)
cat("\n================ Marginal M (SD) by factor ================\n")
print(marginals %>% mutate(across(c(M, SD), ~round(.x, 2))), n = Inf)

# marginal mean + SD for chatGPT ratings

combined_ambigu %>%
  filter(Rater == "GPT") %>%
  summarise(
    across(c(Suitability, Suitability_gpt4o, Suitability_gpt41),
           list(M = ~mean(.x, na.rm = TRUE),
                SD = ~sd(.x,   na.rm = TRUE)),
           .names = "{.col}_{.fn}")
  )


# ----- 3. Floor / ceiling frequency by condition -----------------------------
# Two readings: exact boundary (== min / == max) and a near-boundary band.
floor_ceiling <- dx %>%
  group_by(ApplicantAge, ApplicantGender, JobAge, Condition) %>%
  summarise(
    n               = n(),
    n_floor_exact   = sum(Suitability == SCALE_MIN,            na.rm = TRUE),
    n_ceiling_exact = sum(Suitability == SCALE_MAX,            na.rm = TRUE),
    n_floor_band    = sum(Suitability <= SCALE_MIN + NEAR_BAND, na.rm = TRUE),
    n_ceiling_band  = sum(Suitability >= SCALE_MAX - NEAR_BAND, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(
    pct_floor_exact   = n_floor_exact   / n,
    pct_ceiling_exact = n_ceiling_exact / n,
    pct_floor_band    = n_floor_band    / n,
    pct_ceiling_band  = n_ceiling_band  / n
  ) %>%
  arrange(ApplicantAge, ApplicantGender, JobAge)

cat("\n================ Floor / ceiling by condition ================\n")
cat("Exact: value == ", SCALE_MIN, " or == ", SCALE_MAX,
    ".  Band: within ", NEAR_BAND, " of a boundary.\n", sep = "")
print(
  floor_ceiling %>%
    transmute(Condition, n,
              `Floor%(exact)`   = label_percent(accuracy = 0.1)(pct_floor_exact),
              `Ceiling%(exact)` = label_percent(accuracy = 0.1)(pct_ceiling_exact),
              `Floor%(band)`    = label_percent(accuracy = 0.1)(pct_floor_band),
              `Ceiling%(band)`  = label_percent(accuracy = 0.1)(pct_ceiling_band)),
  n = Inf
)

# Save both tables so you can drop them into the manuscript / supplement.
write_csv(desc_by_condition, file.path(OUT_DIR, "gpt54_descriptives_by_condition.csv"))
write_csv(floor_ceiling,     file.path(OUT_DIR, "gpt54_floor_ceiling_by_condition.csv"))


# ----- 4. APA-conform density figure -----------------------------------------
# APA figure conventions implemented here:
#   - clean panel, no gridlines, single axis lines, black ticks
#   - sans-serif legible type (swap base_family if your journal wants serif)
#   - grayscale + linetype for ApplicantAge so it survives black-and-white print
#   - x-axis bounded to the real scale; a rug shows the raw points behind the KDE


theme_apa <- function(base_size = 12, base_family = "serif") {
  theme_minimal(base_size = base_size, base_family = base_family) +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.border     = element_blank(),
      axis.line        = element_line(color = "black", linewidth = 0.4),
      axis.ticks       = element_line(color = "black", linewidth = 0.4),
      axis.title       = element_text(face = "bold"),
      strip.background = element_blank(),
      strip.text       = element_text(face = "bold"),
      legend.position  = "right",
      legend.title     = element_text(face = "bold"),
      plot.title       = element_text(face = "plain", hjust = 0, size = 12),
      plot.title.position = "plot",
      plot.margin      = margin(8, 12, 8, 8)
    )
}

# ---- English display labels (figure only; analysis data stays Dutch) --------
# This relabels factor LEVELS for the plot without touching `dx`, so the
# descriptive/floor-ceiling tables and any downstream models keep the original
# Dutch coding. Mapping is new = old.
lab_age    <- c(Young = "Jong", Old = "Oud")     # ApplicantAge & JobAge
lab_gender <- c(Male  = "Man",  Female = "Vrouw")

dx_plot <- dx %>%
  mutate(
    ApplicantAge    = fct_recode(ApplicantAge,    !!!lab_age),
    JobAge          = fct_recode(JobAge,          !!!lab_age),
    ApplicantGender = fct_recode(ApplicantGender, !!!lab_gender)
  )

# Age-overlay layout (the version you uploaded): ApplicantAge is the focal
# within-panel contrast (Young vs Old), the panel grid is JobAge (rows) x
# ApplicantGender (columns). ApplicantAge drives fill + line style so each
# panel is a direct Young-vs-Old comparison that survives grayscale print.
fig_density <- ggplot(
  dx_plot,
  aes(
    x = Suitability,
    linetype = ApplicantAge,
    fill = ApplicantAge
  )
) +
  
  geom_hline(
    yintercept = 0,
    color = "black",
    linewidth = 0.2
  ) +
  
  geom_density(
    alpha = 0.25,
    color = "black",
    linewidth = 0.2,
    bounds = c(60, SCALE_MAX)
  ) +
  
  facet_grid(
    JobAge ~ ApplicantGender,
    labeller = labeller(
      JobAge = function(x) paste("Job age:", x),
      ApplicantGender = function(x) paste("Applicant:", x)
    )
  ) +
  
  scale_fill_grey(
    start = 0.25,
    end = 0.75
  ) +
  
  scale_x_continuous(
    breaks = seq(60, SCALE_MAX, by = 10),
    expand = c(0, 0)
  ) +
  
  scale_y_continuous(
    breaks = seq(0, 0.90, by = 0.30),
    expand = c(0, 0)
  ) +
  
  coord_cartesian(
    xlim = c(60, SCALE_MAX),
    ylim = c(0, 0.90)
  ) +
  
  labs(
    x = "Suitability rating (1-100)",
    y = "Density",
    linetype = "Applicant age",
    fill = "Applicant age"
  ) +
  
  theme_apa() +
  
  theme(
    panel.spacing.x = unit(1, "lines"),
    panel.spacing.y = unit(1.5, "lines")
  )

# Drop the rug for a cleaner panel? Remove the geom_rug() block above.

# Prefer a baked-in title? Add: fig_density <- fig_density +
#   labs(title = "GPT54 Suitability Density by Condition")

ggsave(file.path(OUT_DIR, "Figure_density_gpt54.png"),
       fig_density, width = FIG_W, height = FIG_H, dpi = 300, bg = "white")
ggsave(file.path(OUT_DIR, "Figure_density_gpt54.pdf"),
       fig_density, width = FIG_W, height = FIG_H)

cat("\nFigure written: Figure_density_gpt54.png / .pdf\n")


# ----- 5. APA caption text (Word) ---------------------------------
# Place the number + title ABOVE the inserted image, the note BELOW it.
cat("\n--------- APA caption to place in your manuscript ---------\n")
cat("Figure X\n")
cat("Distribution of ChatGPT-5.4 Suitability Ratings by Applicant Age, ",
    "Applicant Gender, and Job Age\n", sep = "")
cat("\nNote. Suitability was rated on a 1-100 scale. Curves are kernel density ",
    "estimates bounded to the scale range; tick marks at the base of each panel ",
    "show individual ratings. Solid lines = younger applicants, dashed lines = ",
    "older applicants. Panels are arranged by applicant gender (columns) and ",
    "job age (rows). N = ", nrow(dx), ".\n", sep = "")

cat("\nDone.\n")



# =====================================================================================
# Test whether means and sds differ significantly between HR professionals and ChatGPT
# =====================================================================================

library(dplyr)

# 1. Grand mean per rater type, collapsed across age, gender, job age-type
desc <- combined_ambigu %>%
  group_by(Rater) %>%
  summarise(
    n  = n(),
    M  = mean(Suitability, na.rm = TRUE),
    SD = sd(Suitability,   na.rm = TRUE),
    .groups = "drop"
  )
print(desc)

# 2. Welch's t-test. var.equal = FALSE is the R default and the right
#    choice here, because your variances differ roughly tenfold and
#    Student's t would be invalid.
welch <- t.test(Suitability ~ Rater, data = combined_ambigu, var.equal = FALSE)
print(welch)



# =============================================================================
# H1 - complete analysis in the order reported in the Results section
# Outcome: Suitability (1-100). Raters: HR vs GPT. 3 manipulated factors
# (ApplicantAge, ApplicantGender, JobAge); JobGenderCat = measured control.
# H1 model uses ApplicantAge * Rater + JobGenderCat (gender/JobAge enter in H2-H4).
# =============================================================================

library(tidyverse)
library(car)          # Anova(type = 3)
library(emmeans)      # simple effects
library(effectsize)   # partial eta^2, cohens_d
library(nlme)         # gls() unequal-variance model

options(contrasts = c("contr.sum", "contr.poly"))   # effect coding

# Factor setup (safe to re-run; assumes `dat` already built from combined_ambigu)
dat <- combined_ambigu %>%
  mutate(
    ApplicantAge = factor(ApplicantAge, levels = c("Jong", "Oud")),
    Rater        = factor(Rater,        levels = c("HR",   "GPT")),
    JobGenderCat = factor(JobGenderCat, levels = c("male", "neutral", "female"))
  )


# =============================================================================
# STEP 1. Model 1: pooled OLS 
# =============================================================================
model_h1 <- lm(Suitability ~ JobGenderCat + ApplicantAge * Rater, data = dat)

cat("\n=== STEP 1: Model 1 (pooled OLS) ===\n")
cat("R^2 =", round(summary(model_h1)$r.squared, 3), "\n\n")
aov_ols <- Anova(model_h1, type = 3)        # omnibus age F, interaction F
print(aov_ols)
cat("\n--- Partial eta^2 (OLS) ---\n")
eta_ols <- eta_squared(model_h1, partial = TRUE, ci = .90)
print(eta_ols)
cat("\n--- Coefficients (OLS) ---\n")
print(round(summary(model_h1)$coefficients, 4))


# =============================================================================
# STEP 2. Homoscedasticity check  
# =============================================================================
cat("\n=== STEP 2: variance check ===\n")

gls_equal <- gls(Suitability ~ JobGenderCat + ApplicantAge * Rater,
                 data = dat, method = "REML")
gls_uneq  <- gls(Suitability ~ JobGenderCat + ApplicantAge * Rater,
                 data = dat, weights = varIdent(form = ~ 1 | Rater),
                 method = "REML")

cat("\n--- LRT: equal vs unequal residual variance ---\n")
lrt <- anova(gls_equal, gls_uneq)
print(lrt)

res_sd <- sigma(gls_uneq) *
  c(1, coef(gls_uneq$modelStruct$varStruct, unconstrained = FALSE))
names(res_sd)[1] <- levels(dat$Rater)[1]
cat("\n--- Residual SD by Rater ---\n")
print(round(res_sd, 3))


# =============================================================================
# STEP 3. Variance-robust model  (text: gls interaction + simple effects)
# =============================================================================
cat("\n=== STEP 3: variance-robust gls ===\n")
aov_gls <- anova(gls_uneq, type = "marginal")
print(aov_gls)

cat("\n--- gls simple effects: age within each Rater ---\n")
emm_gls <- emmeans(gls_uneq, ~ ApplicantAge | Rater, mode = "df.error")
print(emm_gls)
print(pairs(emm_gls, adjust = "none"))

library(effectsize)
cat("\n--- partial eta^2 (from OLS twin) ---\n")
print(eta_squared(model_h1, partial = TRUE, ci = .90))


# =============================================================================
# STEP 4. Separate per-rater models + Welch 
# =============================================================================
cat("\n=== STEP 4: separate per-rater models ===\n")
dat_hr  <- filter(dat, Rater == "HR")
dat_gpt <- filter(dat, Rater == "GPT")

m_hr  <- lm(Suitability ~ JobGenderCat + ApplicantAge, data = dat_hr)
m_gpt <- lm(Suitability ~ JobGenderCat + ApplicantAge, data = dat_gpt)

cat("\n--- HR only ---\n");  print(Anova(m_hr,  type = 3))
print(eta_squared(m_hr,  partial = TRUE, ci = .90))
emm_hr <- emmeans(m_hr, ~ ApplicantAge)
print(pairs(emm_hr, adjust = "none"))
d_hr <- eff_size(emm_hr, sigma = sigma(m_hr), edf = df.residual(m_hr))
print(d_hr)

cat("\n--- GPT only ---\n"); print(Anova(m_gpt, type = 3))
print(eta_squared(m_gpt, partial = TRUE, ci = .90))
emm_gpt <- emmeans(m_gpt, ~ ApplicantAge)
print(pairs(emm_gpt, adjust = "none"))
d_gpt <- eff_size(emm_gpt, sigma = sigma(m_gpt), edf = df.residual(m_gpt))
print(d_gpt)


# =============================================================================
# STEP 5. Scale use  
# =============================================================================
cat("\n=== STEP 5: scale use (means by Rater) ===\n")
print(dat %>% group_by(Rater) %>%
        summarise(M = mean(Suitability), SD = sd(Suitability), n = n(),
                  .groups = "drop"))


# =============================================================================
# STEP 6. Within-rater standardization  
# =============================================================================
cat("\n=== STEP 6: within-rater standardized ===\n")
dat <- dat %>% group_by(Rater) %>%
  mutate(Suitability_z = as.numeric(scale(Suitability))) %>% ungroup()

model_h1_z <- lm(Suitability_z ~ JobGenderCat + ApplicantAge * Rater, data = dat)
print(Anova(model_h1_z, type = 3))
emm_z <- emmeans(model_h1_z, ~ ApplicantAge | Rater)
cat("\n--- standardized age penalty within each Rater (SD units) ---\n")
print(pairs(emm_z, adjust = "none"))


# =============================================================================
# STEP 7. Assemble Table 
# =============================================================================
cat("\n=== STEP 7: Table ===\n")

aov_ols_df <- as.data.frame(aov_ols)
aov_gls_df <- as.data.frame(aov_gls)
eta_ols_df <- as.data.frame(eta_ols)

get_ols <- function(term) aov_ols_df[term, c("F value", "Pr(>F)")]
get_gls <- function(term) aov_gls_df[term, c("F-value", "p-value")]
get_eta <- function(term) eta_ols_df$Eta2_partial[eta_ols_df$Parameter == term]

panelA <- tibble(
  Effect = c("Job gender-type (control)", "Applicant age",
             "Rater type", "Applicant age x Rater type"),
  df     = c("2, 1996", "1, 1996", "1, 1996", "1, 1996"),
  F_OLS  = round(c(get_ols("JobGenderCat")[1,1], get_ols("ApplicantAge")[1,1],
                   get_ols("Rater")[1,1], get_ols("ApplicantAge:Rater")[1,1]), 2),
  p_OLS  = round(c(get_ols("JobGenderCat")[1,2], get_ols("ApplicantAge")[1,2],
                   get_ols("Rater")[1,2], get_ols("ApplicantAge:Rater")[1,2]), 3),
  eta2p  = round(c(get_eta("JobGenderCat"), get_eta("ApplicantAge"),
                   get_eta("Rater"), get_eta("ApplicantAge:Rater")), 3),
  F_gls  = round(c(get_gls("JobGenderCat")[1,1], get_gls("ApplicantAge")[1,1],
                   get_gls("Rater")[1,1], get_gls("ApplicantAge:Rater")[1,1]), 2),
  p_gls  = round(c(get_gls("JobGenderCat")[1,2], get_gls("ApplicantAge")[1,2],
                   get_gls("Rater")[1,2], get_gls("ApplicantAge:Rater")[1,2]), 3)
)

eta_hr  <- eta_squared(m_hr,  partial = TRUE)$Eta2_partial[
  eta_squared(m_hr, partial = TRUE)$Parameter == "ApplicantAge"]
eta_gpt <- eta_squared(m_gpt, partial = TRUE)$Eta2_partial[
  eta_squared(m_gpt, partial = TRUE)$Parameter == "ApplicantAge"]

panelB <- tibble(
  Rater   = c("HR professionals", "ChatGPT-5.4"),
  M_young = round(c(mean(dat_hr$Suitability[dat_hr$ApplicantAge == "Jong"]),
                    mean(dat_gpt$Suitability[dat_gpt$ApplicantAge == "Jong"])), 1),
  M_old   = round(c(mean(dat_hr$Suitability[dat_hr$ApplicantAge == "Oud"]),
                    mean(dat_gpt$Suitability[dat_gpt$ApplicantAge == "Oud"])), 1),
  F       = round(c(Anova(m_hr, type = 3)["ApplicantAge", "F value"],
                    Anova(m_gpt, type = 3)["ApplicantAge", "F value"]), 2),
  df      = c("1, 398", "1, 1596"),
  p       = round(c(Anova(m_hr, type = 3)["ApplicantAge", "Pr(>F)"],
                    Anova(m_gpt, type = 3)["ApplicantAge", "Pr(>F)"]), 3),
  eta2p   = round(c(eta_hr, eta_gpt), 3),
  d       = round(c(as.data.frame(d_hr)$effect.size,
                    as.data.frame(d_gpt)$effect.size), 2),
  d_low   = round(c(as.data.frame(d_hr)$lower.CL,
                    as.data.frame(d_gpt)$lower.CL), 2),
  d_high  = round(c(as.data.frame(d_hr)$upper.CL,
                    as.data.frame(d_gpt)$upper.CL), 2)
)

cat("\n--- Table, Panel A (omnibus) ---\n"); print(panelA)
cat("\n--- Table, Panel B (simple effects) ---\n"); print(panelB)

write_csv(panelA, "table_panelA_omnibus.csv")
write_csv(panelB, "table_panelB_simple_effects.csv")
cat("\nSaved table_panelA_omnibus.csv and table_panelB_simple_effects.csv\n")

# =============================================================================
# Additional analyses 
#   A) Bayesian evidence for/against the age effect (per rater, homoscedastic)
#   B) (optional) Bayesian interaction BF allowing unequal variance (brms)
#   C) Fisher's z: compare age-suitability correlation across the two raters
# =============================================================================

install.packages("BayesFactor")

# -----------------------------------------------------------------------------
# A) Bayesian t-tests of the age effect WITHIN each rater (BayesFactor)
# BF10 > 1 favours an age effect; BF01 = 1/BF10 favours null.
# -----------------------------------------------------------------------------
library(BayesFactor)

bf_hr  <- ttestBF(formula = Suitability ~ ApplicantAge, data = as.data.frame(dat_hr))
bf_gpt <- ttestBF(formula = Suitability ~ ApplicantAge, data = as.data.frame(dat_gpt))

cat("\n--- Bayesian t-test: age effect within HR ---\n")
print(bf_hr)
cat("BF10 =", round(as.vector(bf_hr), 3),
    " | BF01 =", round(1 / as.vector(bf_hr), 3), "\n")   # expect BF01 > 1 (null)

cat("\n--- Bayesian t-test: age effect within ChatGPT ---\n")
print(bf_gpt)
cat("BF10 =", round(as.vector(bf_gpt), 3),
    " | BF01 =", round(1 / as.vector(bf_gpt), 3), "\n")   # expect huge BF10


# =============================================================================
# H2-H4 - complete analyses in the order reported in the Results section

#   - AgeMismatch composite replaces the applicant-age x job-age structure.
#     H3a (age x jobage interaction)  -> AgeMismatch MAIN effect.
#     H3b (age x jobage x rater)      -> AgeMismatch x Rater interaction.
#   - No four-way interaction. H4 is run as AgeMismatch x ApplicantGender
#     SEPARATELY within each rater. H4b is therefore a descriptive comparison
#     of the two per-rater interactions, NOT a single omnibus test.
# =============================================================================

library(tidyverse)
library(car)          # Anova(type = 3)
library(emmeans)      # simple effects / interaction contrasts
library(effectsize)   # partial eta^2, cohens_d
library(nlme)         # gls() unequal-variance model
library(BayesFactor)  # ttestBF, lmBF

options(contrasts = c("contr.sum", "contr.poly"))   # effect coding

# ---- Setup: factors + the match/mismatch composite --------------------------
# Assumes `dat` already exists (the cleaned combined_ambigu used for H1).
dat <- dat %>%
  mutate(
    ApplicantAge    = factor(ApplicantAge,    levels = c("Jong", "Oud")),
    ApplicantGender = factor(ApplicantGender, levels = c("Man",  "Vrouw")),
    JobAge          = factor(JobAge,          levels = c("Jong", "Oud")),
    Rater           = factor(Rater,           levels = c("HR",   "GPT")),
    JobGenderCat    = factor(JobGenderCat,    levels = c("male", "neutral", "female")),
    # H3/H4 composite: a "match" is applicant age == job age-type.
    # CONFIRM this matches your Method-section definition before trusting H3/H4.
    AgeMismatch     = factor(if_else(ApplicantAge == JobAge, "Match", "Mismatch"),
                             levels = c("Match", "Mismatch"))
  )

dat_hr  <- filter(dat, Rater == "HR")
dat_gpt <- filter(dat, Rater == "GPT")

# ---- Small helpers ----------------------------------------------------------
# Residual SD per rater from a fitted gls (sanity check; expect ~20.6 vs ~1.7).
gls_res_sd <- function(g) {
  s <- sigma(g) * c(1, coef(g$modelStruct$varStruct, unconstrained = FALSE))
  names(s)[1] <- levels(dat$Rater)[1]
  round(s, 3)
}

# Within-rater model-comparison Bayes factor for ONE focal interaction term.
# Returns BF10 (alt/null) for adding `focal` to the reduced model.
bf_interaction <- function(d, full_rhs, reduced_rhs) {
  d <- as.data.frame(d)
  lmBF(as.formula(paste("Suitability ~", full_rhs)),    data = d, rscaleFixed = 0.707) /
    lmBF(as.formula(paste("Suitability ~", reduced_rhs)), data = d, rscaleFixed = 0.707)
}

# =============================================================================
# H2: ApplicantAge x ApplicantGender (+ Rater moderation)
#   H2a: age x gender interaction (older women rated lower than older men)
#   H2b: age x gender x rater (interaction differs between raters)
# =============================================================================
cat("\n##################  H2  ##################\n")

# --- STEP 1. Model 2: pooled OLS (omnibus + Table Rater) --------------------
model_h2 <- lm(Suitability ~ JobGenderCat + ApplicantAge * ApplicantGender * Rater,
               data = dat)
cat("\n=== H2 STEP 1: Model 2 (pooled OLS) ===\n")
cat("R^2 =", round(summary(model_h2)$r.squared, 3), "\n\n")
print(Anova(model_h2, type = 3))
cat("\n--- Partial eta^2 (OLS) ---\n")
print(eta_squared(model_h2, partial = TRUE, ci = .90))

emm_h2 <- emmeans(model_h2, ~ ApplicantGender | ApplicantAge * Rater)
print(emm_h2)
print(pairs(emm_h2, adjust = "none"))   # Vrouw - Man at each Age x Rater combo

# --- STEP 2. Variance check + LRT (same heteroscedasticity as H1) ------------
cat("\n=== H2 STEP 2: variance check ===\n")
gls2_equal <- gls(Suitability ~ JobGenderCat + ApplicantAge * ApplicantGender * Rater,
                  data = dat, method = "REML")
gls2_uneq  <- gls(Suitability ~ JobGenderCat + ApplicantAge * ApplicantGender * Rater,
                  data = dat, weights = varIdent(form = ~ 1 | Rater), method = "REML")
print(anova(gls2_equal, gls2_uneq))            # LRT: unequal variance should win
cat("\n--- Residual SD by Rater ---\n"); print(gls_res_sd(gls2_uneq))

# --- STEP 3. Variance-robust focal tests (H2a, H2b) --------------------------
cat("\n=== H2 STEP 3: variance-robust gls ===\n")
print(anova(gls2_uneq, type = "marginal"))     # ApplicantAge:ApplicantGender = H2a
# ...:Rater (3-way)            = H2b

# --- STEP 4. Per-rater simple effects + Welch --------------------------------
cat("\n=== H2 STEP 4: per-rater age x gender ===\n")
m2_hr  <- lm(Suitability ~ JobGenderCat + ApplicantAge * ApplicantGender, data = dat_hr)
m2_gpt <- lm(Suitability ~ JobGenderCat + ApplicantAge * ApplicantGender, data = dat_gpt)
summary(m2_hr)
summary(m2_gpt)

for (nm in c("HR", "GPT")) {
  m   <- if (nm == "HR") m2_hr else m2_gpt
  cat("\n--- ", nm, " ---\n", sep = "")
  print(Anova(m, type = 3))
  print(eta_squared(m, partial = TRUE, ci = .90))
  # age effect within each gender, and the difference of those (the interaction)
  emm <- emmeans(m, ~ ApplicantAge | ApplicantGender)
  print(pairs(emm, adjust = "none"))
  print(contrast(emm, interaction = "pairwise"))   # age x gender contrast
}


## Figure
#scal 1-100

library(emmeans); library(ggplot2); library(dplyr)

emm_df <- as.data.frame(emmeans(m2_gpt, ~ ApplicantAge * ApplicantGender)) %>%
  mutate(
    ApplicantAge    = factor(ApplicantAge,    levels = c("Jong","Oud"),  labels = c("Younger","Older")),
    ApplicantGender = factor(ApplicantGender, levels = c("Man","Vrouw"), labels = c("Male","Female"))
  )

p_cells <- ggplot(emm_df, aes(x = ApplicantAge, y = emmean, fill = ApplicantGender)) +
  geom_col(position = position_dodge(0.7), width = 0.6, colour = "black", linewidth = 0.4) +
  geom_errorbar(aes(ymin = lower.CL, ymax = upper.CL),
                position = position_dodge(0.7), width = 0.15, linewidth = 0.4) +
  scale_fill_manual(values = c("Male" = "grey40", "Female" = "grey75")) +
  coord_cartesian(ylim = c(0, 100)) +
  labs(x = "Applicant age", y = "Estimated suitability rating", fill = "Applicant gender") +
  theme_classic(base_size = 12) +
  theme(text = element_text(family = "serif", colour = "black"),
        axis.text = element_text(colour = "black"),
        axis.line = element_line(colour = "black"),
        legend.position = "right")

ggsave(
  "C:/Users/mschella/OneDrive - UGent/Documents/Onderzoek/Doctoraat/5. ChatGPT/JBP/Revision 2/Figure3_GPT_age_gender_cells.png",
  p_cells,
  width = 6,
  height = 4.5,
  dpi = 300
)

#scale 61-100
library(emmeans); library(ggplot2); library(dplyr)

emm_df <- as.data.frame(emmeans(m2_gpt, ~ ApplicantAge * ApplicantGender)) %>%
  mutate(
    ApplicantAge    = factor(ApplicantAge,    levels = c("Jong","Oud"),  labels = c("Younger","Older")),
    ApplicantGender = factor(ApplicantGender, levels = c("Man","Vrouw"), labels = c("Male","Female"))
  )

p_cells <- ggplot(emm_df, aes(x = ApplicantAge, y = emmean, fill = ApplicantGender)) +
  geom_col(position = position_dodge(0.7), width = 0.6, colour = "black", linewidth = 0.4) +
  geom_errorbar(aes(ymin = lower.CL, ymax = upper.CL),
                position = position_dodge(0.7), width = 0.15, linewidth = 0.4) +
  scale_fill_manual(values = c("Male" = "grey40", "Female" = "grey75")) +
  coord_cartesian(ylim = c(60, 100)) +
  labs(x = "Applicant age", y = "Estimated suitability rating", fill = "Applicant gender") +
  theme_classic(base_size = 12) +
  theme(text = element_text(family = "serif", colour = "black"),
        axis.text = element_text(colour = "black"),
        axis.line = element_line(colour = "black"),
        legend.position = "right")

ggsave(
  "C:/Users/mschella/OneDrive - UGent/Documents/Onderzoek/Doctoraat/5. ChatGPT/JBP/Revision 2/Figure3_GPT_age_gender_cells.png",
  p_cells,
  width = 6,
  height = 4.5,
  dpi = 300
)


# --- STEP 5. (Optional) within-rater standardized check ----------------------

dat_z2 <- dat %>%
  group_by(Rater) %>%
  mutate(Suitability_z = as.numeric(scale(Suitability))) %>%
  ungroup()

print(Anova(
  lm(Suitability_z ~ JobGenderCat + ApplicantAge * ApplicantGender * Rater,
     data = dat_z2),
  type = 3
))

d_gpt <- eff_size(emm_gpt, sigma = sigma(m_gpt), edf = df.residual(m_gpt))
print(d_gpt)

## decomposing significant three-way interaction

m_z <- lm(Suitability_z ~ JobGenderCat + ApplicantAge * ApplicantGender * Rater, data = dat_z2)

# (a) The age x gender interaction WITHIN each rater (standardized)
emm_ag <- emmeans(m_z, ~ ApplicantAge * ApplicantGender | Rater)
contrast(emm_ag, interaction = "pairwise")    # one interaction estimate per rater

# (b) The simple age effect (Younger - Older) for each gender, within each rater
emm_simple <- emmeans(m_z, ~ ApplicantAge | ApplicantGender * Rater)
pairs(emm_simple)                              # Younger - Older in each gender x rater cell

# (c) The 8 standardized cell means (for a table or figure)
emmeans(m_z, ~ ApplicantAge * ApplicantGender * Rater)

# --- STEP 6. Bayesian evidence (within rater, model comparison) --------------
cat("\n=== H2 STEP 6: within-rater Bayes factor for age x gender ===\n")
set.seed(123)
bf2_hr  <- bf_interaction(dat_hr,
                          "JobGenderCat + ApplicantAge + ApplicantGender + ApplicantAge:ApplicantGender",
                          "JobGenderCat + ApplicantAge + ApplicantGender")
set.seed(123)
bf2_gpt <- bf_interaction(dat_gpt,
                          "JobGenderCat + ApplicantAge + ApplicantGender + ApplicantAge:ApplicantGender",
                          "JobGenderCat + ApplicantAge + ApplicantGender")
cat("HR  : BF10 =", round(as.vector(bf2_hr), 3),
    "| BF01 =", round(1/as.vector(bf2_hr), 3), "\n")
cat("GPT : BF10 =", round(as.vector(bf2_gpt), 3),
    "| BF01 =", round(1/as.vector(bf2_gpt), 3), "\n")

# =============================================================================
# H3 (explicit factors) and H4 (composite), both as pooled three-way models
# Parallels the H2 template: pooled OLS -> variance check -> variance-robust
# gls -> per-rater simple effects -> within-rater Bayesian.
#
# H3: ApplicantAge x JobAge x Rater  (NO composite)
#       ApplicantAge:JobAge            = H3a (mismatch effect, explicit)
#       ApplicantAge:JobAge:Rater      = H3b (does it differ by rater)
#     Focal contrasts are identical to the AgeMismatch version you already ran:
#       ApplicantAge:JobAge        == AgeMismatch main effect
#       ApplicantAge:JobAge:Rater  == AgeMismatch:Rater
#     so the new numbers should reproduce the earlier ones (cross-check).
#
# H4: AgeMismatch x ApplicantGender x Rater  (composite, pooled three-way)
#       AgeMismatch:ApplicantGender        = H4a
#       AgeMismatch:ApplicantGender:Rater  = H4b  (a 3-way, not a 4-way)

# =============================================================================

library(tidyverse)
library(car)          # Anova(type = 3)
library(emmeans)      # simple effects / interaction contrasts
library(effectsize)   # partial eta^2
library(nlme)         # gls() unequal-variance model
library(BayesFactor)  # lmBF model comparison

options(contrasts = c("contr.sum", "contr.poly"))   # effect coding

# ---- Setup (assumes `dat` is the cleaned combined_ambigu used for H1) ------
dat <- dat %>%
  mutate(
    ApplicantAge    = factor(ApplicantAge,    levels = c("Jong", "Oud")),
    ApplicantGender = factor(ApplicantGender, levels = c("Man",  "Vrouw")),
    JobAge          = factor(JobAge,          levels = c("Jong", "Oud")),
    Rater           = factor(Rater,           levels = c("HR",   "GPT")),
    JobGenderCat    = factor(JobGenderCat,    levels = c("male", "neutral", "female")),
    AgeMismatch     = factor(if_else(ApplicantAge == JobAge, "Match", "Mismatch"),
                             levels = c("Match", "Mismatch"))
  )
dat_hr  <- filter(dat, Rater == "HR")
dat_gpt <- filter(dat, Rater == "GPT")

gls_res_sd <- function(g) {
  s <- sigma(g) * c(1, coef(g$modelStruct$varStruct, unconstrained = FALSE))
  names(s)[1] <- levels(dat$Rater)[1]; round(s, 3)
}
# Within-rater model-comparison Bayes factor for ONE focal interaction term.
bf_interaction <- function(d, full_rhs, reduced_rhs) {
  d <- as.data.frame(d)
  lmBF(as.formula(paste("Suitability ~", full_rhs)),    data = d, rscaleFixed = 0.707) /
    lmBF(as.formula(paste("Suitability ~", reduced_rhs)), data = d, rscaleFixed = 0.707)
}

# =============================================================================
# H3: ApplicantAge x JobAge x Rater  (explicit factors, no composite)
#   H3a: ApplicantAge:JobAge  (mismatched rated lower than matched)
#   H3b: ApplicantAge:JobAge:Rater
# =============================================================================
cat("\n##################  H3 (explicit 3-way)  ##################\n")

# --- STEP 1. Pooled OLS ------------------------------------------------------
model_h3 <- lm(Suitability ~ JobGenderCat + ApplicantAge * JobAge * Rater, data = dat)
cat("\n=== H3 STEP 1: Model 3 (pooled OLS) ===\n")
cat("R^2 =", round(summary(model_h3)$r.squared, 3), "\n\n")
print(Anova(model_h3, type = 3))   # ApplicantAge:JobAge = H3a; :Rater = H3b
print(eta_squared(model_h3, partial = TRUE, ci = .90))

# --- STEP 2. Variance check + LRT --------------------------------------------
cat("\n=== H3 STEP 2: variance check ===\n")
gls3_equal <- gls(Suitability ~ JobGenderCat + ApplicantAge * JobAge * Rater,
                  data = dat, method = "REML")
gls3_uneq  <- gls(Suitability ~ JobGenderCat + ApplicantAge * JobAge * Rater,
                  data = dat, weights = varIdent(form = ~ 1 | Rater), method = "REML")
print(anova(gls3_equal, gls3_uneq))
cat("\n--- Residual SD by Rater ---\n"); print(gls_res_sd(gls3_uneq))

# --- STEP 3. Variance-robust focal tests (H3a, H3b) --------------------------
cat("\n=== H3 STEP 3: variance-robust gls ===\n")
print(anova(gls3_uneq, type = "marginal"))   # ApplicantAge:JobAge / :Rater are focal
cat("\n--- gls simple effects: age x jobage within each Rater ---\n")
emm3_gls <- emmeans(gls3_uneq, ~ ApplicantAge | JobAge * Rater, mode = "df.error")
print(contrast(emm3_gls, interaction = "pairwise", by = "Rater"))   # age x jobage per rater

# --- STEP 4. Per-rater models + interaction contrasts ------------------------
cat("\n=== H3 STEP 4: per-rater age x jobage ===\n")
m3_hr  <- lm(Suitability ~ JobGenderCat + ApplicantAge * JobAge, data = dat_hr)
m3_gpt <- lm(Suitability ~ JobGenderCat + ApplicantAge * JobAge, data = dat_gpt)
for (nm in c("HR", "GPT")) {
  m <- if (nm == "HR") m3_hr else m3_gpt
  cat("\n--- ", nm, " ---\n", sep = "")
  print(Anova(m, type = 3)); print(eta_squared(m, partial = TRUE, ci = .90))
  emm <- emmeans(m, ~ ApplicantAge | JobAge)
  print(emmeans(m, ~ ApplicantAge * JobAge))            # 2x2 cell means
  print(pairs(emm, adjust = "none"))                    # age within each job-age
  print(contrast(emm, interaction = "pairwise"))        # the age x jobage contrast
}

## figure sigificant interaction applicant age x job age in CHatGPT

library(emmeans); library(ggplot2); library(dplyr)

emm_df <- as.data.frame(emmeans(m3_gpt, ~ ApplicantAge * JobAge)) %>%
  mutate(
    ApplicantAge = factor(ApplicantAge, levels = c("Jong","Oud"), labels = c("Younger","Older")),
    JobAge       = factor(JobAge,       levels = c("Jong","Oud"), labels = c("Young-typed","Old-typed"))
  )

p_cells <- ggplot(emm_df, aes(x = ApplicantAge, y = emmean, fill = JobAge)) +
  geom_col(position = position_dodge(0.7), width = 0.6, colour = "black", linewidth = 0.4) +
  geom_errorbar(aes(ymin = lower.CL, ymax = upper.CL),
                position = position_dodge(0.7), width = 0.15, linewidth = 0.4) +
  scale_fill_manual(values = c("Young-typed" = "grey40", "Old-typed" = "grey75")) +
  coord_cartesian(ylim = c(60, 100)) +
  labs(x = "Applicant age", y = "Estimated suitability rating", fill = "Job age-type") +
  theme_classic(base_size = 12) +
  theme(text = element_text(family = "serif", colour = "black"),
        axis.text = element_text(colour = "black"),
        axis.line = element_line(colour = "black"),
        legend.position = "right")

ggsave(
  "C:/Users/mschella/OneDrive - UGent/Documents/Onderzoek/Doctoraat/5. ChatGPT/JBP/Revision 2/Figure4_GPT_age_jobage_cells.png",
  p_cells,
  width = 6,
  height = 4.5,
  dpi = 300
)


# --- STEP 5. (Optional) within-rater standardized check ----------------------

dat_z2 <- dat %>%
  group_by(Rater) %>%
  mutate(Suitability_z = as.numeric(scale(Suitability))) %>%
  ungroup()

print(Anova(
  lm(Suitability_z ~ JobGenderCat + ApplicantAge * JobAge * Rater,
     data = dat_z2),
  type = 3
))

# --- STEP 6. Bayesian (within rater, model comparison for the interaction) ---
cat("\n=== H3 STEP 6: within-rater Bayes factor for age x jobage ===\n")
set.seed(123)
bf3_hr  <- bf_interaction(dat_hr,
                          "JobGenderCat + ApplicantAge + JobAge + ApplicantAge:JobAge",
                          "JobGenderCat + ApplicantAge + JobAge")
set.seed(123)
bf3_gpt <- bf_interaction(dat_gpt,
                          "JobGenderCat + ApplicantAge + JobAge + ApplicantAge:JobAge",
                          "JobGenderCat + ApplicantAge + JobAge")
cat("HR  : BF10 =", round(as.vector(bf3_hr), 3),
    "| BF01 =", round(1/as.vector(bf3_hr), 3), "\n")
cat("GPT : BF10 =", round(as.vector(bf3_gpt), 3),
    "| BF01 =", round(1/as.vector(bf3_gpt), 3), "\n")


# =============================================================================
# H4: AgeMismatch x ApplicantGender x Rater  (composite, pooled three-way)
#   H4a: AgeMismatch:ApplicantGender
#   H4b: AgeMismatch:ApplicantGender:Rater   (three-way, not four-way)
# =============================================================================
cat("\n##################  H4 (composite 3-way)  ##################\n")

# --- STEP 1. Pooled OLS ------------------------------------------------------
model_h4 <- lm(Suitability ~ JobGenderCat + AgeMismatch * ApplicantGender * Rater,
               data = dat)
cat("\n=== H4 STEP 1: Model 4 (pooled OLS) ===\n")
cat("R^2 =", round(summary(model_h4)$r.squared, 3), "\n\n")
print(Anova(model_h4, type = 3))   # AgeMismatch:ApplicantGender = H4a; :Rater = H4b
print(eta_squared(model_h4, partial = TRUE, ci = .90))

# --- STEP 2. Variance check + LRT --------------------------------------------
cat("\n=== H4 STEP 2: variance check ===\n")
gls4_equal <- gls(Suitability ~ JobGenderCat + AgeMismatch * ApplicantGender * Rater,
                  data = dat, method = "REML")
gls4_uneq  <- gls(Suitability ~ JobGenderCat + AgeMismatch * ApplicantGender * Rater,
                  data = dat, weights = varIdent(form = ~ 1 | Rater), method = "REML")
print(anova(gls4_equal, gls4_uneq))
cat("\n--- Residual SD by Rater ---\n"); print(gls_res_sd(gls4_uneq))

# --- STEP 3. Variance-robust focal tests (H4a, H4b) --------------------------
cat("\n=== H4 STEP 3: variance-robust gls ===\n")
print(anova(gls4_uneq, type = "marginal"))
cat("\n--- gls simple effects: mismatch x gender within each Rater ---\n")
emm4_gls <- emmeans(gls4_uneq, ~ AgeMismatch | ApplicantGender * Rater, mode = "df.error")
print(contrast(emm4_gls, interaction = "pairwise", by = "Rater"))   # mismatch x gender per rater

# --- STEP 4. Per-rater models + interaction contrasts ------------------------
cat("\n=== H4 STEP 4: per-rater mismatch x gender ===\n")
m4_hr  <- lm(Suitability ~ JobGenderCat + AgeMismatch * ApplicantGender, data = dat_hr)
m4_gpt <- lm(Suitability ~ JobGenderCat + AgeMismatch * ApplicantGender, data = dat_gpt)
for (nm in c("HR", "GPT")) {
  m <- if (nm == "HR") m4_hr else m4_gpt
  cat("\n--- ", nm, " ---\n", sep = "")
  print(Anova(m, type = 3)); print(eta_squared(m, partial = TRUE, ci = .90))
  emm <- emmeans(m, ~ AgeMismatch | ApplicantGender)
  print(emmeans(m, ~ AgeMismatch * ApplicantGender))   # 2x2 cell means
  print(pairs(emm, adjust = "none"))
  print(contrast(emm, interaction = "pairwise"))        # the H4a interaction
}

# --- STEP 5. (Optional) within-rater standardized check ----------------------

dat_z2 <- dat %>%
  group_by(Rater) %>%
  mutate(Suitability_z = as.numeric(scale(Suitability))) %>%
  ungroup()

print(Anova(
  lm(Suitability_z ~ JobGenderCat + AgeMismatch * ApplicantGender * Rater,
     data = dat_z2),
  type = 3
))


# --- STEP 6. Bayesian (within rater, model comparison for the interaction) ---
cat("\n=== H4 STEP 6: within-rater Bayes factor for mismatch x gender ===\n")
set.seed(123)
bf4_hr  <- bf_interaction(dat_hr,
                          "JobGenderCat + AgeMismatch + ApplicantGender + AgeMismatch:ApplicantGender",
                          "JobGenderCat + AgeMismatch + ApplicantGender")
set.seed(123)
bf4_gpt <- bf_interaction(dat_gpt,
                          "JobGenderCat + AgeMismatch + ApplicantGender + AgeMismatch:ApplicantGender",
                          "JobGenderCat + AgeMismatch + ApplicantGender")
cat("HR  : BF10 =", round(as.vector(bf4_hr), 3),
    "| BF01 =", round(1/as.vector(bf4_hr), 3), "\n")
cat("GPT : BF10 =", round(as.vector(bf4_gpt), 3),
    "| BF01 =", round(1/as.vector(bf4_gpt), 3), "\n")



# =============================================================================
# Table creation: Table 6
# Outputs: APA-formatted Word documents + CSV backups
#
# Required objects in the environment (run H1-H4 scripts first):
#   H1 : model_h1, gls_uneq,   m_hr, m_gpt
#   H2 : model_h2, gls2_uneq
#   H3 : model_h3, gls3_uneq   (explicit ApplicantAge x JobAge x Rater)
#   H4 : model_h4, gls4_uneq   (composite AgeMismatch x Gender x Rater)
#   BFs: bf_hr, bf_gpt          (H1 within-rater, from ttestBF)
#        bf2_hr, bf2_gpt        (H2 within-rater, from lmBF comparison)
#        bf3_hr, bf3_gpt        (H3 within-rater, from lmBF comparison)
#        bf4_hr, bf4_gpt        (H4 within-rater, from lmBF comparison)
# =============================================================================

install.packages(c("flextable", "officer"))

library(tidyverse)
library(car)         # Anova()
library(nlme)        # gls S3 method for anova()
library(emmeans)     # emmeans(), eff_size(), pairs()
library(effectsize)  # eta_squared()
library(flextable)   # APA table formatting
library(officer)     # Word export

# ---- 0a. User-supplied Bayes factors ----------------------------------------
# Values extracted from your BF objects. Update if you re-run any analysis.
# H1: ttestBF within rater; H2-H4: lmBF model comparison within rater.
bf_vals <- list(
  H1_hr_01  = round(1 / as.vector(bf_hr),  2),   # BF01 for HR age effect
  H1_gpt_10 = round(as.vector(bf_gpt), 0),        # BF10 for GPT age effect (huge)
  H2_hr_01  = round(1 / as.vector(bf2_hr), 2),
  H2_gpt_01 = round(1 / as.vector(bf2_gpt), 2),
  H3_hr_01  = round(1 / as.vector(bf3_hr), 2),
  H3_gpt_01 = round(1 / as.vector(bf3_gpt), 2),
  H4_hr_01  = round(1 / as.vector(bf4_hr), 2),
  H4_gpt_01 = round(1 / as.vector(bf4_gpt), 2)
)

# Format for the BF column in the supplement table
bf_text <- list(
  H1a = paste0("HR: BF\u2080\u2081 = ", bf_vals$H1_hr_01,
               " | GPT: BF\u2081\u2080 > 10\u00B9\u00B2"),
  H2a = paste0("HR: BF\u2080\u2081 = ", bf_vals$H2_hr_01,
               " | GPT: BF\u2080\u2081 = ", bf_vals$H2_gpt_01),
  H3a = paste0("HR: BF\u2080\u2081 = ", bf_vals$H3_hr_01,
               " | GPT: BF\u2080\u2081 = ", bf_vals$H3_gpt_01),
  H4a = paste0("HR: BF\u2080\u2081 = ", bf_vals$H4_hr_01,
               " | GPT: BF\u2080\u2081 = ", bf_vals$H4_gpt_01)
)

# ---- 0b. Formatting helpers -------------------------------------------------
# APA p-value: no leading zero, < .001 for very small values
fmt_p <- function(x) {
  sapply(as.numeric(x), function(p) {
    if (is.na(p)) return("")
    if (p < .001)  return("< .001")
    sub("^0", "", sprintf("%.3f", p))
  }, USE.NAMES = FALSE)
}
# F to 2 decimal places
fmt_F <- function(x) ifelse(is.na(x), "", sprintf("%.2f", as.numeric(x)))

# η²p: < .001 if tiny, else 3dp, no leading zero
fmt_eta <- function(x) {
  sapply(as.numeric(x), function(e) {
    if (is.na(e)) return("")
    if (e < .001)  return("< .001")
    sub("^0", "", sprintf("%.3f", e))
  }, USE.NAMES = FALSE)
}

# ---- 0c. Extraction helpers -------------------------------------------------
# Extract OLS Anova (Type III) → data frame (excluding intercept/residuals)
get_ols <- function(model) {
  aov  <- as.data.frame(Anova(model, type = 3))
  aov$Effect <- rownames(aov)
  aov  <- aov[!aov$Effect %in% c("(Intercept)", "Residuals"), ]
  data.frame(
    Effect  = aov$Effect,
    numDF   = aov$Df,
    denDF   = df.residual(model),
    F_ols   = aov[["F value"]],
    p_ols   = aov[["Pr(>F)"]],
    stringsAsFactors = FALSE
  )
}

# Extract gls marginal anova — calls anova.gls directly to avoid dispatch
# issues when car or other packages alter the anova generic
get_gls <- function(gls_model) {
  aov  <- as.data.frame(nlme:::anova.gls(gls_model, type = "marginal"))
  aov$Effect <- rownames(aov)
  aov  <- aov[!aov$Effect %in% "(Intercept)", ]
  data.frame(
    Effect  = aov$Effect,
    F_gls   = aov[["F-value"]],
    p_gls   = aov[["p-value"]],
    stringsAsFactors = FALSE
  )
}

# Extract partial η²p (robust to column-name differences across effectsize versions)
get_eta <- function(model) {
  eta <- as.data.frame(eta_squared(model, partial = TRUE, ci = .90))
  data.frame(Effect = eta[[1]], eta2p = eta[[2]], stringsAsFactors = FALSE)
}

# Combine OLS + gls + η²p into one block, formatted
build_block <- function(ols_model, gls_model,
                        focal_a = NULL, focal_b = NULL,
                        bf_a = "", bf_b = "") {
  ols <- get_ols(ols_model)
  gls <- get_gls(gls_model)
  eta <- get_eta(ols_model)
  
  tab <- ols %>%
    left_join(eta, by = "Effect") %>%
    left_join(gls, by = "Effect") %>%
    mutate(
      df      = paste0(numDF, ", ", denDF),
      F_ols_f = fmt_F(F_ols),
      p_ols_f = fmt_p(p_ols),
      eta_f   = fmt_eta(eta2p),
      F_gls_f = fmt_F(F_gls),
      p_gls_f = fmt_p(p_gls),
      BF      = case_when(
        Effect == focal_a ~ bf_a,
        Effect == focal_b ~ bf_b,
        TRUE              ~ ""
      ),
      Focal   = case_when(
        Effect == focal_a ~ "a",
        Effect == focal_b ~ "b",
        TRUE              ~ ""
      )
    ) %>%
    select(Effect, df, F_ols_f, p_ols_f, eta_f, F_gls_f, p_gls_f, BF, Focal)
  tab
}

# ---- 0d. Display labels for effect names ------------------------------------
effect_labels <- c(
  "JobGenderCat"                        = "Job gender-type (control)",
  "ApplicantAge"                        = "Applicant age",
  "ApplicantGender"                     = "Applicant gender",
  "JobAge"                              = "Job age-type",
  "AgeMismatch"                         = "Age match/mismatch",
  "Rater"                               = "Rater type",
  "ApplicantAge:ApplicantGender"        = "Applicant age \u00D7 Gender",
  "ApplicantAge:JobAge"                 = "Applicant age \u00D7 Job age-type",
  "AgeMismatch:ApplicantGender"         = "Age mismatch \u00D7 Gender",
  "ApplicantAge:Rater"                  = "Applicant age \u00D7 Rater type",
  "ApplicantGender:Rater"               = "Applicant gender \u00D7 Rater type",
  "JobAge:Rater"                        = "Job age-type \u00D7 Rater type",
  "AgeMismatch:Rater"                   = "Age mismatch \u00D7 Rater type",
  "ApplicantAge:ApplicantGender:Rater"  = "Applicant age \u00D7 Gender \u00D7 Rater type",
  "ApplicantAge:JobAge:Rater"           = "Applicant age \u00D7 Job age-type \u00D7 Rater type",
  "AgeMismatch:ApplicantGender:Rater"   = "Age mismatch \u00D7 Gender \u00D7 Rater type"
)
relabel <- function(x) ifelse(x %in% names(effect_labels), effect_labels[x], x)



# =============================================================================
# TABLE 6 (H1-H4, all models side by side)
# =============================================================================
cat("--- Building Supplement Table ---\n")

# Build each model block
block_h1 <- build_block(model_h1, gls_uneq,
                        focal_a = "ApplicantAge",
                        focal_b = "ApplicantAge:Rater",
                        bf_a = bf_text$H1a)

block_h2 <- build_block(model_h2, gls2_uneq,
                        focal_a = "ApplicantAge:ApplicantGender",
                        focal_b = "ApplicantAge:ApplicantGender:Rater",
                        bf_a = bf_text$H2a)

block_h3 <- build_block(model_h3, gls3_uneq,
                        focal_a = "ApplicantAge:JobAge",
                        focal_b = "ApplicantAge:JobAge:Rater",
                        bf_a = bf_text$H3a)

block_h4 <- build_block(model_h4, gls4_uneq,
                        focal_a = "AgeMismatch:ApplicantGender",
                        focal_b = "AgeMismatch:ApplicantGender:Rater",
                        bf_a = bf_text$H4a)

# Add header rows identifying each model block
model_header <- function(label, ncol = 9) {
  h <- as.data.frame(matrix("", 1, ncol))
  h[1, 1] <- label
  names(h) <- names(block_h1)
  h
}
supp <- bind_rows(
  model_header("Model 1 (H1): Applicant age \u00D7 Rater type"),
  block_h1,
  model_header("Model 2 (H2): Applicant age \u00D7 Gender \u00D7 Rater type"),
  block_h2,
  model_header("Model 3 (H3): Applicant age \u00D7 Job age-type \u00D7 Rater type"),
  block_h3,
  model_header("Model 4 (H4): Age mismatch \u00D7 Gender \u00D7 Rater type (composite)"),
  block_h4
) %>%
  mutate(Effect = relabel(Effect),
         # Mark focal a and b terms with superscripts in the Effect column
         Effect = case_when(
           Focal == "a" ~ paste0(Effect, "\u1D43"),
           Focal == "b" ~ paste0(Effect, "\u1D47"),
           TRUE         ~ Effect
         )) %>%
  select(-Focal)

# Export CSV backup
write_csv(supp, "Table5_H1_H4.csv")

# Format for Word
names(supp) <- c("Effect", "df", "F (OLS)", "p (OLS)", "\u03B7\u00B2p",
                 "F (gls)", "p (gls)", "BF")
# Row indices of model header rows (for bold formatting)
header_rows <- which(supp$df == "")

ft_supp <- flextable(supp) %>%
  bold(part = "header") %>%
  bold(i = header_rows) %>%               # bold model block headers
  bg(i = header_rows, bg = "#F2F2F2") %>% # light grey background for headers
  border_remove() %>%
  hline_top(border = officer::fp_border(width = 1.5), part = "header") %>%
  hline_bottom(border = officer::fp_border(width = 0.75), part = "header") %>%
  hline_bottom(border = officer::fp_border(width = 1.5), part = "body") %>%
  hline(i = header_rows,
        border = officer::fp_border(width = 0.5, color = "grey60"),
        part = "body") %>%
  align(align = "center", part = "all") %>%
  align(j = 1, align = "left", part = "body") %>%
  fontsize(size = 9, part = "all") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  set_caption("Table S[x]. Ordinary Least Squares and Variance-Robust Tests for All Four Models") %>%
  autofit()

doc_supp <- read_docx() %>%
  body_add_par("Table 6", style = "heading 1") %>%
  body_add_par(paste(
    "Ordinary Least Squares and Variance-Robust (gls) Tests for Models 1-4"
  ), style = "Normal") %>%
  body_add_flextable(ft_supp) %>%
  body_add_par(paste(
    "Note. N = 1,998 (HR n = 398, ChatGPT n = 1,600).",
    "Suitability rated 1-100. All models used effect (sum-to-zero) coding",
    "with job gender-type as a control.",
    "OLS = ordinary least squares; gls = generalized least squares",
    "with rater-specific residual variances; \u03B7\u00B2p = partial eta-squared (from OLS).",
    "For every model, a likelihood-ratio test favoured rater-specific variances (all p < .001);",
    "the gls columns provide the variance-robust tests.",
    "BF = within-rater Bayes factor (JZS prior, r = .707), computed",
    "via ttestBF (H1a) or lmBF model comparison (H2a-H4a) within each rater type.",
    "BF\u2080\u2081 > 1 favours the null. Superscripts:",
    "\u1D43 = focal test for hypothesis [n]a;",
    "\u1D47 = focal test for hypothesis [n]b (rater-type moderation).",
    "Denom. df per model: H1 = 1,992; H2 = 1,988; H3 = 1,988; H4 = 1,988."
  ), style = "Normal")
print(doc_supp, target = "Table5_H1_H4.docx")
cat("Saved: Table5_H1_H4.docx\n")
cat("\nDone. Check Table3_H1.docx and Table5_H1_H4.docx.\n")


# =============================================================================
# Coefficient tables for Models 1-4 (gls, variance-robust)
# Extracts B, SE, t, p, and 95% CI for each predictor.
# Outputs: one Word document with four model tables + CSV backups.
# =============================================================================

library(tidyverse)
library(nlme)        # gls; needed for summary.gls
library(flextable)   # APA formatting
library(officer)     # Word export

# ---- 0. Formatting helpers --------------------------------------------------
fmt_b  <- function(x) sprintf("%.2f", as.numeric(x))
fmt_se <- function(x) sprintf("%.2f", as.numeric(x))
fmt_t  <- function(x) sprintf("%.2f", as.numeric(x))
fmt_p  <- function(x) {
  sapply(as.numeric(x), function(p) {
    if (is.na(p)) return("")
    if (p < .001)  return("< .001")
    sub("^0", "", sprintf("%.3f", p))
  }, USE.NAMES = FALSE)
}
fmt_ci <- function(lo, hi) {
  paste0("[", sprintf("%.2f", lo), ", ", sprintf("%.2f", hi), "]")
}

# ---- 1. Predictor name cleaner ----------------------------------------------
# Strips trailing digits (effect-coding artefact), replaces with display labels,
# and joins interaction parts with " x ".
clean_predictor <- function(nm) {
  if (nm == "(Intercept)") return("Intercept")
  parts <- strsplit(nm, ":")[[1]]
  
  # Specific labels for numbered multi-level contrasts (checked BEFORE stripping digits).
  # With levels = c("male","neutral","female") and contr.sum:
  #   JobGenderCat1 = male vs grand mean
  #   JobGenderCat2 = neutral vs grand mean  (female is the omitted/reference level)
  level_lkp <- c(
    "JobGenderCat1" = "Job gender-type (male)",
    "JobGenderCat2" = "Job gender-type (neutral)"
  )
  
  # General lookup for 2-level factors (applied after stripping trailing digit)
  lkp <- c(
    "ApplicantAge"    = "Applicant age",
    "ApplicantGender" = "Applicant gender",
    "JobAge"          = "Job age-type",
    "AgeMismatch"     = "Age mismatch",
    "Rater"           = "Rater type"
  )
  
  parts_clean <- sapply(parts, function(p) {
    if (p %in% names(level_lkp)) {
      level_lkp[p]                          # e.g. "JobGenderCat1" -> "(male)"
    } else {
      p_stripped <- gsub("\\d+$", "", p)    # strip digit for 2-level factors
      if (p_stripped %in% names(lkp)) lkp[p_stripped] else p_stripped
    }
  }, USE.NAMES = FALSE)
  
  paste(parts_clean, collapse = " x ")
}

# ---- 2. Extract coefficient table from a gls model -------------------------
# 95% CI approximated as B +/- 1.96 * SE (exact for large N).
get_coef_table <- function(gls_model, model_label) {
  tt  <- summary(gls_model)$tTable          # Value, Std.Error, t-value, p-value
  df  <- as.data.frame(tt)
  df$Predictor <- rownames(df)
  
  df %>%
    mutate(
      Predictor = sapply(Predictor, clean_predictor),
      CI_lo     = df[["Value"]] - 1.96 * df[["Std.Error"]],
      CI_hi     = df[["Value"]] + 1.96 * df[["Std.Error"]],
      B_f       = fmt_b(df[["Value"]]),
      SE_f      = fmt_se(df[["Std.Error"]]),
      CI_f      = fmt_ci(CI_lo, CI_hi),
      t_f       = fmt_t(df[["t-value"]]),
      p_f       = fmt_p(df[["p-value"]])
    ) %>%
    select(Predictor, B_f, SE_f, CI_f, t_f, p_f) %>%
    rename(B = B_f, SE = SE_f, `95% CI` = CI_f, t = t_f, p = p_f) %>%
    mutate(Model = model_label, .before = 1)
}


# ---- 3. ONE combined table: Models 1-4 side by side -------------------------
# Cell format: B*** (SE). Reuses your clean_predictor() from section 1.

# Significance stars (APA)
stars <- function(p) ifelse(p < .001, "***",
                            ifelse(p < .01,  "**",
                                   ifelse(p < .05,  "*", "")))

# One formatted cell per predictor for a given gls model
get_coef_cells <- function(gls_model, model_label) {
  tt <- as.data.frame(summary(gls_model)$tTable)   # Value, Std.Error, t-value, p-value
  tibble(
    Predictor = unname(sapply(rownames(tt), clean_predictor)),
    cell = sprintf("%.2f%s (%.2f)", tt[["Value"]], stars(tt[["p-value"]]), tt[["Std.Error"]])
  ) %>%
    rename(!!model_label := cell)
}

cells_h1 <- get_coef_cells(gls_uneq,  "Model 1 (H1)")
cells_h2 <- get_coef_cells(gls2_uneq, "Model 2 (H2)")
cells_h3 <- get_coef_cells(gls3_uneq, "Model 3 (H3)")
cells_h4 <- get_coef_cells(gls4_uneq, "Model 4 (H4)")

# Row order. Predictors absent from a model stay blank in that column.
pred_order <- c(
  "Intercept",
  "Job gender-type (male)", "Job gender-type (neutral)","Rater type",
  "Applicant age", "Applicant gender", "Job age-type", "Age mismatch", "Applicant age x Rater type", 
  "Applicant age x Applicant gender", "Applicant age x Job age-type",
  "Age mismatch x Applicant gender",
  "Applicant gender x Rater type",
  "Job age-type x Rater type", "Age mismatch x Rater type",
  "Applicant age x Applicant gender x Rater type",
  "Applicant age x Job age-type x Rater type",
  "Age mismatch x Applicant gender x Rater type"
)

coef_wide <- list(cells_h1, cells_h2, cells_h3, cells_h4) %>%
  reduce(full_join, by = "Predictor") %>%
  mutate(ord = match(Predictor, pred_order)) %>%
  arrange(ord) %>%
  select(-ord) %>%
  mutate(across(everything(), ~ replace_na(.x, "")))

write_csv(coef_wide, "Table6_Study2_coefficients_wide_H1_H4.csv")

# ---- 4. Format the single combined table ------------------------------------
note_txt <- paste(
  "Note. N = 1,998 (HR n = 398, ChatGPT n = 1,600). Cells show the unstandardized",
  "coefficient with its standard error in parentheses, from the variance-robust gls",
  "model with rater-specific residual variances. Effect (sum-to-zero) coding throughout;",
  "each coefficient is the deviation of the listed level from the grand mean. Omitted",
  "(reference) levels: applicant age = old; applicant gender = female; job age-type = old;",
  "age match/mismatch = mismatch; rater type = ChatGPT; job gender-type = female-typed jobs.",
  "Blank cells indicate the predictor was not in that model.",
  "* p < .05. ** p < .01. *** p < .001."
)

ft <- flextable(coef_wide) %>%
  bold(part = "header") %>%
  border_remove() %>%
  hline_top(border = officer::fp_border(width = 1.5), part = "header") %>%
  hline_bottom(border = officer::fp_border(width = 0.75), part = "header") %>%
  hline_bottom(border = officer::fp_border(width = 1.5), part = "body") %>%
  align(align = "center", part = "all") %>%
  align(j = 1, align = "left", part = "all") %>%
  fontsize(size = 10, part = "all") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  add_footer_lines(note_txt) %>%
  italic(part = "footer") %>%
  fontsize(size = 9, part = "footer") %>%
  set_caption("Table X. Regression Coefficients for Models 1-4 (Variance-Robust gls)") %>%
  autofit()

# ---- 5. Export one Word table -----------------------------------------------
doc <- read_docx() %>%
  body_add_par("Table 6", style = "heading 1") %>%
  body_add_par("Regression Coefficients Predicting Suitability Across Models 1-4",
               style = "Normal") %>%
  body_add_flextable(ft)

print(doc, target = "Table6_Study2_Coefficients_combined_H1_H4.docx")
cat("Saved: able6_Study2_Coefficients_combined_H1_H4.docx and coefficients_wide_H1_H4.csv\n")



# ============================================================
# Within-rater age effects on job suitability: GPT-4o and GPT-4.1
# Controls for job gender-type; tests the focal interactions.
# Run within EACH AI rater, separately:
#   H1  age main effect             (rating ~ ApplicantAge + JobGenderCat)
#   H2  age x applicant gender      (+ JobGenderCat control)
#   H3  age x job age-type          (+ JobGenderCat control)
#   H4  age mismatch x app. gender  (+ JobGenderCat control)
# Per model: OLS Type III F-test + partial eta^2, and a Bayesian
# BF for the focal term (full vs reduced via lmBF).
#
# Single rater => OLS is the within-rater model. The rater-specific-
# variance gls used in the cross-rater models reduces to OLS here;
# for robustness to unequal cell variances, use sandwich SEs on the lm.
# ============================================================

library(tidyverse)
library(BayesFactor)
library(effectsize)
library(car)
library(emmeans)

# Effect (sum-to-zero) coding, as in the earlier models
options(contrasts = c("contr.sum", "contr.poly"))

# ── 0. DATA ──────────────────────────────────────────────────
gpt_dat <- combined_ambigu %>%
  filter(Rater == "GPT")          # HR rows are NA on the gpt columns

scale_min <- 0
scale_max <- 100
ai_cols   <- c("Suitability_gpt4o", "Suitability_gpt41")

needed <- c("ApplicantAge", "ApplicantGender", "JobAge", "JobGenderCat", ai_cols)
missing_cols <- setdiff(needed, names(gpt_dat))
if (length(missing_cols) > 0) {
  stop(paste0("Missing columns: ", paste(missing_cols, collapse = ", "),
              "\nAvailable: ", paste(names(gpt_dat), collapse = ", ")))
}

gpt_dat <- gpt_dat %>%
  mutate(
    ApplicantAge    = factor(ApplicantAge),
    ApplicantGender = factor(ApplicantGender),
    JobAge          = factor(JobAge),
    JobGenderCat       = factor(JobGenderCat),        # <- drop this line if continuous
    # Age match/mismatch: applicant age vs job age-type
    AgeMismatch = factor(
      if_else(as.character(ApplicantAge) == as.character(JobAge),
              "match", "mismatch"),
      levels = c("match", "mismatch"))
  )

cat("Levels -> ApplicantAge:", paste(levels(gpt_dat$ApplicantAge), collapse = "/"),
    "| JobAge:", paste(levels(gpt_dat$JobAge), collapse = "/"),
    "| AgeMismatch:", paste(levels(gpt_dat$AgeMismatch), collapse = "/"), "\n")
# Confirm AgeMismatch lines up with your intended young/old coding before trusting H4.

# ── 1. HYPOTHESIS SPECS (focal term + full/reduced models) ───
# Every model controls for JobGenderCat.
hyps <- list(
  H2 = list(
    label   = "ApplicantAge x ApplicantGender",
    term    = "ApplicantAge:ApplicantGender",
    full    = rating ~ ApplicantAge + ApplicantGender + ApplicantAge:ApplicantGender + JobGenderCat,
    reduced = rating ~ ApplicantAge + ApplicantGender + JobGenderCat,
    emm     = pairwise ~ ApplicantAge | ApplicantGender   # age effect within each gender
  ),
  H3 = list(
    label   = "ApplicantAge x JobAge-type",
    term    = "ApplicantAge:JobAge",
    full    = rating ~ ApplicantAge + JobAge + ApplicantAge:JobAge + JobGenderCat,
    reduced = rating ~ ApplicantAge + JobAge + JobGenderCat,
    emm     = pairwise ~ ApplicantAge | JobAge            # age effect within each job age-type
  ),
  H4 = list(
    label   = "ApplicantAge x JobAge-type x ApplicantGender",
    term    = "ApplicantAge:JobAge:ApplicantGender",
    full    = rating ~ ApplicantAge * JobAge * ApplicantGender + JobGenderCat,
    reduced = rating ~ (ApplicantAge + JobAge + ApplicantGender)^2 + JobGenderCat,
    emm     = pairwise ~ ApplicantAge * JobAge | ApplicantGender  # Age x JobAge cells within each gender
  )
)


# ── 2. HELPERS ───────────────────────────────────────────────
# H1: controlled OLS age effect + uncontrolled t-test/BF + scale use
run_h1 <- function(d) {
  cat("\n-- Means, SDs, scale use by applicant age --\n")
  print(as.data.frame(
    d %>% group_by(ApplicantAge) %>%
      summarise(n = n(), M = mean(rating), SD = sd(rating),
                Min = min(rating), Max = max(rating),
                pct_floor = mean(rating == scale_min) * 100,
                pct_ceil  = mean(rating == scale_max) * 100,
                .groups = "drop")), digits = 3)
  
  cat("\n-- Welch t-test (uncontrolled simple effect): rating ~ ApplicantAge --\n")
  print(t.test(rating ~ ApplicantAge, data = d, var.equal = FALSE))
  print(cohens_d(rating ~ ApplicantAge, data = d))
  
  cat("\n-- OLS, age controlling for JobGenderCat: rating ~ ApplicantAge + JobGenderCat --\n")
  m  <- lm(rating ~ ApplicantAge + JobGenderCat, data = d)
  a3 <- car::Anova(m, type = 3)
  print(a3)
  print(eta_squared(a3, partial = TRUE))
  cat("Coefficients (B, SE, t, p) with 95% CI [effect coding]:\n")
  print(round(cbind(summary(m)$coefficients, confint(m)), 3))
  
  cat("\n-- Bayesian t-test (uncontrolled): rating ~ ApplicantAge --\n")
  bf <- ttestBF(formula = rating ~ ApplicantAge, data = as.data.frame(d))
  print(bf)
  cat("BF10 =", signif(as.vector(bf), 4), "| BF01 =", round(1 / as.vector(bf), 3), "\n")
  invisible(list(lm = m, anova = a3, bf = bf))
}

# H2-H4: focal interaction F-test + partial eta^2 + Bayesian BF
run_interaction <- function(d, spec) {
  cat("\n-- ", spec$label, " --\n", sep = "")
  m  <- lm(spec$full, data = d)
  a3 <- car::Anova(m, type = 3)
  cat("OLS Type III ANOVA:\n"); print(a3)
  cat("Partial eta^2:\n"); print(eta_squared(a3, partial = TRUE))
  
  cat("Coefficients (B, SE, t, p) with 95% CI [effect coding]:\n")
  print(round(cbind(summary(m)$coefficients, confint(m)), 3))
  
  # Estimated marginal means + simple-effect contrasts (response scale).
  # This is what gives direction, cell means, and the per-group age gap.
  emm <- emmeans(m, spec$emm)
  cat("\nEstimated marginal means:\n");      print(emm$emmeans)
  cat("Simple-effect contrasts:\n");          print(emm$contrasts)
  
  bf_full <- lmBF(spec$full,    data = as.data.frame(d))
  bf_red  <- lmBF(spec$reduced, data = as.data.frame(d))
  bf_int  <- bf_full / bf_red
  b10 <- as.vector(bf_int)
  cat("Bayesian BF for", spec$term, "interaction (full vs reduced):\n")
  cat("  BF10 =", signif(b10, 4), "| BF01 =", round(1 / b10, 3), "\n")
  invisible(list(lm = m, anova = a3, emmeans = emm, bf = bf_int))
}

# ── 3. RUN, EACH RATER SEPARATELY ────────────────────────────
results <- list()
for (col in ai_cols) {
  cat("\n\n========================================================\n")
  cat("RATER:", col, "\n")
  cat("========================================================\n")
  
  d <- gpt_dat %>%
    mutate(rating = .data[[col]]) %>%
    filter(!is.na(rating)) %>%
    droplevels()
  
  cat("n =", nrow(d),
      "| overall SD =", round(sd(d$rating), 3),
      "| range =", round(min(d$rating), 1), "to", round(max(d$rating), 1), "\n")
  
  res <- list(H1 = run_h1(d))
  for (h in names(hyps)) res[[h]] <- run_interaction(d, hyps[[h]])
  results[[col]] <- res
}

# Stored objects, e.g. results$Suitability_gpt4o$H2$bf , $H3$anova , etc.

# ── 4. APA COEFFICIENT TABLE: models side-by-side, one table per rater ──
library(tidyverse)
library(broom)
library(flextable)
library(officer)

## 4a. Long table with APA-formatted cells: "B*** (SE)" ------------------
star <- function(p) dplyr::case_when(
  p < .001 ~ "***",
  p < .01  ~ "**",
  p < .05  ~ "*",
  TRUE     ~ ""
)

coef_long <- imap_dfr(results, function(rater_res, rater) {
  imap_dfr(rater_res, function(res, h) {
    broom::tidy(res$lm) %>%
      transmute(
        Rater = rater,
        Model = h,
        Term  = term,
        cell  = sprintf("%.2f%s (%.2f)", estimate, star(p.value), std.error)
      )
  })
})

## 4b. Pretty predictor labels + row order -------------------------------

term_labels <- c(
  "(Intercept)"                            = "Intercept",
  "JobGenderCat1"                          = "Job gender-type (male)",
  "JobGenderCat2"                          = "Job gender-type (neutral)",
  "ApplicantAge1"                          = "Applicant age (young)",
  "ApplicantGender1"                       = "Applicant gender (male)",
  "JobAge1"                                = "Job age-type (young)",
  "ApplicantAge1:ApplicantGender1"         = "Applicant age \u00D7 Applicant gender",
  "ApplicantAge1:JobAge1"                  = "Applicant age \u00D7 Job age-type",
  "JobAge1:ApplicantGender1"               = "Job age-type \u00D7 Applicant gender",
  "ApplicantAge1:JobAge1:ApplicantGender1" = "Applicant age \u00D7 Job age-type \u00D7 Applicant gender"
)

term_order <- names(term_labels)

# Warn if a real term has no label and would be silently dropped
unmapped <- setdiff(unique(coef_long$Term), term_order)
if (length(unmapped)) warning("Unmapped terms (add to term_labels): ",
                              paste(unmapped, collapse = ", "))

## 4c. Model column order + headers --------------------------------------
model_order  <- c("H1", "H2", "H3", "H4")
model_header <- c(H1 = "Model 1 (H1)", H2 = "Model 2 (H2)",
                  H3 = "Model 3 (H3)", H4 = "Model 4 (H4)")

## 4d. Build one APA flextable for a single rater ------------------------
build_apa <- function(df) {
  wide <- df %>%
    filter(Term %in% term_order) %>%
    mutate(Term  = factor(Term, levels = term_order),
           Model = factor(Model, levels = model_order)) %>%
    arrange(Term) %>%
    select(Term, Model, cell) %>%
    pivot_wider(names_from = Model, values_from = cell,
                values_fill = "", names_expand = TRUE) %>%
    mutate(Predictor = unname(term_labels[as.character(Term)])) %>%
    select(Predictor, all_of(model_order))
  
  flextable(wide) %>%
    set_header_labels(values = c(Predictor = "Predictor", model_header)) %>%
    theme_booktabs() %>%
    bold(part = "header") %>%
    align(align = "center", part = "all") %>%
    align(j = 1, align = "left", part = "all") %>%
    font(fontname = "Times New Roman", part = "all") %>%
    fontsize(size = 11, part = "all") %>%
    autofit()
}

## 4e. Note (FILL IN the omitted levels after checking levels()) ---------

m <- results$Suitability_gpt4o$H4$lm   # swap in your rater/model name

m$contrasts   # which coding was actually used, per factor
m$xlevels     # the factor levels, in order

for (f in names(m$xlevels)) {
  lv <- m$xlevels[[f]]
  cat(sprintf("%-15s shown: %-25s omitted: %-10s (coding: %s)\n",
              f,
              paste(head(lv, -1), collapse = ", "),
              tail(lv, 1),
              m$contrasts[[f]]))
}

note_txt <- paste(
  "Note. Each cell reports the unstandardized coefficient (B) with its",
  "standard error in parentheses. All predictors used effect (sum-to-zero)",
  "coding, so each coefficient is the deviation of the listed level from the",
  "grand mean, not a difference from a reference category. For a two-level",
  "factor this deviation is half the gap between the two groups. The omitted",
  "level of each factor (equal to the negative sum of the shown levels) was:",
  "applicant age = old, job age-type = old, applicant gender = female,",
  "job gender-type = female. Blank cells mean the",
  "predictor was not in that model.  * p < .05.  ** p < .01.  *** p < .001."
)

## 4f. Write both raters into one Word file ------------------------------

doc <- read_docx()
for (r in names(results)) {
  doc <- doc %>%
    body_add_par(paste0("Table C. Regression Coefficients Predicting Job ",
                        "Suitability Across Models 1-4 (Study 2) (", r, ")"),
                 style = "Normal") %>%
    body_add_flextable(build_apa(filter(coef_long, Rater == r))) %>%
    body_add_par(note_txt, style = "Normal") %>%
    body_add_par("", style = "Normal")
}
print(doc, target = "Study2_TablesA and B_coefficients_APA_sidebyside.docx")




# ============================================================
# Controlvariables
# ============================================================

# Same number of HR rows?
nrow(HR_ambigu); nrow(dat_hr)

# Same participant order? Check the full demographic vectors, not just a few rows.
ok <- nrow(HR_ambigu) == nrow(dat_hr) &&
  all(dat_hr$Leeftijd == HR_ambigu$Leeftijd) &&
  all(as.character(dat_hr$Geslacht) == as.character(HR_ambigu$Geslacht))
ok   # must be TRUE before going further

# Only if ok is TRUE: attach by position
if (ok) dat_hr$SD_mean <- HR_ambigu$SD_mean

# How many raters actually have an SD score?
sum(is.na(dat_hr$SD_mean))


m_sd_h1 <- lm(Suitability ~ JobGenderCat + ApplicantAge +
                Leeftijd + Geslacht + SD_mean, data = dat_hr)
Anova(m_sd_h1, type = 3)

m_sd_h2 <- lm(Suitability ~ JobGenderCat + ApplicantAge * ApplicantGender +
                Leeftijd + Geslacht + SD_mean, data = dat_hr)
Anova(m_sd_h2, type = 3)

m_sd_h3 <- lm(Suitability ~ JobGenderCat + ApplicantAge * JobAge +
                Leeftijd + Geslacht + SD_mean, data = dat_hr)
Anova(m_sd_h3, type = 3)

m_sd_h4 <- lm(Suitability ~ JobGenderCat + AgeMismatch * ApplicantGender +
                Leeftijd + Geslacht + SD_mean, data = dat_hr)
Anova(m_sd_h4, type = 3)



# =============================================================================
# Hypotheses testing without job-gender as control variable
# =============================================================================

# =============================================================================
# H1 
# =============================================================================

library(tidyverse)
library(car)          # Anova(type = 3)
library(emmeans)      # simple effects
library(effectsize)   # partial eta^2, cohens_d
library(nlme)         # gls() unequal-variance model

options(contrasts = c("contr.sum", "contr.poly"))   # effect coding

# Factor setup (safe to re-run; assumes `dat` already built from combined_ambigu)
dat <- combined_ambigu %>%
  mutate(
    ApplicantAge = factor(ApplicantAge, levels = c("Jong", "Oud")),
    Rater        = factor(Rater,        levels = c("HR",   "GPT")),
    JobGenderCat = factor(JobGenderCat, levels = c("male", "neutral", "female"))
  )


# =============================================================================
# STEP 1. Model 1: pooled OLS  
# =============================================================================
model_h1 <- lm(Suitability ~ ApplicantAge * Rater, data = dat)

cat("\n=== STEP 1: Model 1 (pooled OLS) ===\n")
cat("R^2 =", round(summary(model_h1)$r.squared, 3), "\n\n")
aov_ols <- Anova(model_h1, type = 3)        # omnibus age F, interaction F
print(aov_ols)
cat("\n--- Partial eta^2 (OLS) ---\n")
eta_ols <- eta_squared(model_h1, partial = TRUE, ci = .90)
print(eta_ols)
cat("\n--- Coefficients (OLS) ---\n")
print(round(summary(model_h1)$coefficients, 4))


# =============================================================================
# STEP 2. Homoscedasticity check  (text: "strong violation of homoscedasticity")
#   residual SD per rater + LRT equal vs unequal variance
# =============================================================================
cat("\n=== STEP 2: variance check ===\n")

gls_equal <- gls(Suitability ~ ApplicantAge * Rater,
                 data = dat, method = "REML")
gls_uneq  <- gls(Suitability ~ ApplicantAge * Rater,
                 data = dat, weights = varIdent(form = ~ 1 | Rater),
                 method = "REML")

cat("\n--- LRT: equal vs unequal residual variance ---\n")
lrt <- anova(gls_equal, gls_uneq)
print(lrt)

res_sd <- sigma(gls_uneq) *
  c(1, coef(gls_uneq$modelStruct$varStruct, unconstrained = FALSE))
names(res_sd)[1] <- levels(dat$Rater)[1]
cat("\n--- Residual SD by Rater ---\n")
print(round(res_sd, 3))


# =============================================================================
# STEP 3. Variance-robust model  (text: gls interaction + simple effects)
# =============================================================================
cat("\n=== STEP 3: variance-robust gls ===\n")
aov_gls <- anova(gls_uneq, type = "marginal")
print(aov_gls)

cat("\n--- gls simple effects: age within each Rater ---\n")
emm_gls <- emmeans(gls_uneq, ~ ApplicantAge | Rater, mode = "df.error")
print(emm_gls)
print(pairs(emm_gls, adjust = "none"))


# =============================================================================
# STEP 4. Separate per-rater models 
#   "separate models were estimated for HR professionals and ChatGPT"
# =============================================================================
cat("\n=== STEP 4: separate per-rater models ===\n")
dat_hr  <- filter(dat, Rater == "HR")
dat_gpt <- filter(dat, Rater == "GPT")

m_hr  <- lm(Suitability ~ ApplicantAge, data = dat_hr)
m_gpt <- lm(Suitability ~ ApplicantAge, data = dat_gpt)

cat("\n--- HR only ---\n");  print(Anova(m_hr,  type = 3))
print(eta_squared(m_hr,  partial = TRUE, ci = .90))
emm_hr <- emmeans(m_hr, ~ ApplicantAge)
print(pairs(emm_hr, adjust = "none"))
d_hr <- eff_size(emm_hr, sigma = sigma(m_hr), edf = df.residual(m_hr))
print(d_hr)

cat("\n--- GPT only ---\n"); print(Anova(m_gpt, type = 3))
print(eta_squared(m_gpt, partial = TRUE, ci = .90))
emm_gpt <- emmeans(m_gpt, ~ ApplicantAge)
print(pairs(emm_gpt, adjust = "none"))
d_gpt <- eff_size(emm_gpt, sigma = sigma(m_gpt), edf = df.residual(m_gpt))
print(d_gpt)



# =============================================================================
# STEP 5. Scale use  (text: ChatGPT rated higher overall)
# =============================================================================
cat("\n=== STEP 5: scale use (means by Rater) ===\n")
print(dat %>% group_by(Rater) %>%
        summarise(M = mean(Suitability), SD = sd(Suitability), n = n(),
                  .groups = "drop"))


# =============================================================================
# STEP 6. Within-rater standardization  (text: calibrated analysis)
# =============================================================================
cat("\n=== STEP 6: within-rater standardized ===\n")
dat <- dat %>% group_by(Rater) %>%
  mutate(Suitability_z = as.numeric(scale(Suitability))) %>% ungroup()

model_h1_z <- lm(Suitability_z ~ ApplicantAge * Rater, data = dat)
print(Anova(model_h1_z, type = 3))
emm_z <- emmeans(model_h1_z, ~ ApplicantAge | Rater)
cat("\n--- standardized age penalty within each Rater (SD units) ---\n")
print(pairs(emm_z, adjust = "none"))



# =============================================================================
# Bayesion
# =============================================================================

install.packages("BayesFactor")

# -----------------------------------------------------------------------------
# A) Bayesian t-tests of the age effect WITHIN each rater (BayesFactor)
#    Within rater the variance is homogeneous, so this avoids the pooled-
#    variance problem. BF10 > 1 favours an age effect; BF01 = 1/BF10 favours null.
# -----------------------------------------------------------------------------
library(BayesFactor)

bf_hr  <- ttestBF(formula = Suitability ~ ApplicantAge, data = as.data.frame(dat_hr))
bf_gpt <- ttestBF(formula = Suitability ~ ApplicantAge, data = as.data.frame(dat_gpt))

cat("\n--- Bayesian t-test: age effect within HR ---\n")
print(bf_hr)
cat("BF10 =", round(as.vector(bf_hr), 3),
    " | BF01 =", round(1 / as.vector(bf_hr), 3), "\n")   # expect BF01 > 1 (null)

cat("\n--- Bayesian t-test: age effect within ChatGPT ---\n")
print(bf_gpt)
cat("BF10 =", round(as.vector(bf_gpt), 3),
    " | BF01 =", round(1 / as.vector(bf_gpt), 3), "\n")   # expect huge BF10

# =============================================================================
# H2-H4 
# =============================================================================

library(tidyverse)
library(car)          # Anova(type = 3)
library(emmeans)      # simple effects / interaction contrasts
library(effectsize)   # partial eta^2, cohens_d
library(nlme)         # gls() unequal-variance model
library(BayesFactor)  # ttestBF, lmBF

options(contrasts = c("contr.sum", "contr.poly"))   # effect coding

# ---- Setup: factors + the match/mismatch composite --------------------------
# Assumes `dat` already exists (the cleaned combined_ambigu used for H1).
dat <- dat %>%
  mutate(
    ApplicantAge    = factor(ApplicantAge,    levels = c("Jong", "Oud")),
    ApplicantGender = factor(ApplicantGender, levels = c("Man",  "Vrouw")),
    JobAge          = factor(JobAge,          levels = c("Jong", "Oud")),
    Rater           = factor(Rater,           levels = c("HR",   "GPT")),
    JobGenderCat    = factor(JobGenderCat,    levels = c("male", "neutral", "female")),
    # H3/H4 composite: a "match" is applicant age == job age-type.
    # CONFIRM this matches your Method-section definition before trusting H3/H4.
    AgeMismatch     = factor(if_else(ApplicantAge == JobAge, "Match", "Mismatch"),
                             levels = c("Match", "Mismatch"))
  )

dat_hr  <- filter(dat, Rater == "HR")
dat_gpt <- filter(dat, Rater == "GPT")

# ---- Small helpers ----------------------------------------------------------
# Residual SD per rater from a fitted gls (sanity check; expect ~20.6 vs ~1.7).
gls_res_sd <- function(g) {
  s <- sigma(g) * c(1, coef(g$modelStruct$varStruct, unconstrained = FALSE))
  names(s)[1] <- levels(dat$Rater)[1]
  round(s, 3)
}

# Within-rater model-comparison Bayes factor for ONE focal interaction term.
# Returns BF10 (alt/null) for adding `focal` to the reduced model.
bf_interaction <- function(d, full_rhs, reduced_rhs) {
  d <- as.data.frame(d)
  lmBF(as.formula(paste("Suitability ~", full_rhs)),    data = d, rscaleFixed = 0.707) /
    lmBF(as.formula(paste("Suitability ~", reduced_rhs)), data = d, rscaleFixed = 0.707)
}


# =============================================================================
# H2: ApplicantAge x ApplicantGender (+ Rater moderation)
#   H2a: age x gender interaction (older women rated lower than older men)
#   H2b: age x gender x rater (interaction differs between raters)
# =============================================================================
cat("\n##################  H2  ##################\n")

# --- STEP 1. Model 2: pooled OLS (omnibus + Table source) --------------------
model_h2 <- lm(Suitability ~ ApplicantAge * ApplicantGender * Rater,
               data = dat)
cat("\n=== H2 STEP 1: Model 2 (pooled OLS) ===\n")
cat("R^2 =", round(summary(model_h2)$r.squared, 3), "\n\n")
print(Anova(model_h2, type = 3))
cat("\n--- Partial eta^2 (OLS) ---\n")
print(eta_squared(model_h2, partial = TRUE, ci = .90))

emm_h2 <- emmeans(model_h2, ~ ApplicantGender | ApplicantAge * Rater)
print(emm_h2)
print(pairs(emm_h2, adjust = "none"))   # Vrouw - Man at each Age x Rater combo

# --- STEP 2. Variance check + LRT (same heteroscedasticity as H1) ------------
cat("\n=== H2 STEP 2: variance check ===\n")
gls2_equal <- gls(Suitability ~ ApplicantAge * ApplicantGender * Rater,
                  data = dat, method = "REML")
gls2_uneq  <- gls(Suitability ~ ApplicantAge * ApplicantGender * Rater,
                  data = dat, weights = varIdent(form = ~ 1 | Rater), method = "REML")
print(anova(gls2_equal, gls2_uneq))            # LRT: unequal variance should win
cat("\n--- Residual SD by Rater ---\n"); print(gls_res_sd(gls2_uneq))

# --- STEP 3. Variance-robust focal tests (H2a, H2b) --------------------------
cat("\n=== H2 STEP 3: variance-robust gls ===\n")
print(anova(gls2_uneq, type = "marginal"))     # ApplicantAge:ApplicantGender = H2a
# ...:Rater (3-way)            = H2b

# --- STEP 4. Per-rater simple effects + Welch --------------------------------
cat("\n=== H2 STEP 4: per-rater age x gender ===\n")
m2_hr  <- lm(Suitability ~  ApplicantAge * ApplicantGender, data = dat_hr)
m2_gpt <- lm(Suitability ~  ApplicantAge * ApplicantGender, data = dat_gpt)

for (nm in c("HR", "GPT")) {
  m   <- if (nm == "HR") m2_hr else m2_gpt
  cat("\n--- ", nm, " ---\n", sep = "")
  print(Anova(m, type = 3))
  print(eta_squared(m, partial = TRUE, ci = .90))
  # age effect within each gender, and the difference of those (the interaction)
  emm <- emmeans(m, ~ ApplicantAge | ApplicantGender)
  print(pairs(emm, adjust = "none"))
  print(contrast(emm, interaction = "pairwise"))   # age x gender contrast
}

# --- STEP 5. (Optional) within-rater standardized check ----------------------
# Only report if it changes the conclusion (see H1 Slot 5). Uncomment to run.

dat_z2 <- dat %>%
  group_by(Rater) %>%
  mutate(Suitability_z = as.numeric(scale(Suitability))) %>%
  ungroup()

print(Anova(
  lm(Suitability_z ~ ApplicantAge * ApplicantGender * Rater,
     data = dat_z2),
  type = 3
))

d_gpt <- eff_size(emm_gpt, sigma = sigma(m_gpt), edf = df.residual(m_gpt))
print(d_gpt)



# --- STEP 6. Bayesian evidence (within rater, model comparison) --------------
cat("\n=== H2 STEP 6: within-rater Bayes factor for age x gender ===\n")
set.seed(123)
bf2_hr  <- bf_interaction(dat_hr,
                          "ApplicantAge + ApplicantGender + ApplicantAge:ApplicantGender",
                          "ApplicantAge + ApplicantGender")
set.seed(123)
bf2_gpt <- bf_interaction(dat_gpt,
                          "ApplicantAge + ApplicantGender + ApplicantAge:ApplicantGender",
                          "ApplicantAge + ApplicantGender")
cat("HR  : BF10 =", round(as.vector(bf2_hr), 3),
    "| BF01 =", round(1/as.vector(bf2_hr), 3), "\n")
cat("GPT : BF10 =", round(as.vector(bf2_gpt), 3),
    "| BF01 =", round(1/as.vector(bf2_gpt), 3), "\n")

# =============================================================================
# H3 
# =============================================================================

library(tidyverse)
library(car)          # Anova(type = 3)
library(emmeans)      # simple effects / interaction contrasts
library(effectsize)   # partial eta^2
library(nlme)         # gls() unequal-variance model
library(BayesFactor)  # lmBF model comparison

options(contrasts = c("contr.sum", "contr.poly"))   # effect coding

# ---- Setup (assumes `dat` is the cleaned combined_ambigu used for H1) ------
dat <- dat %>%
  mutate(
    ApplicantAge    = factor(ApplicantAge,    levels = c("Jong", "Oud")),
    ApplicantGender = factor(ApplicantGender, levels = c("Man",  "Vrouw")),
    JobAge          = factor(JobAge,          levels = c("Jong", "Oud")),
    Rater           = factor(Rater,           levels = c("HR",   "GPT")),
    JobGenderCat    = factor(JobGenderCat,    levels = c("male", "neutral", "female")),
    AgeMismatch     = factor(if_else(ApplicantAge == JobAge, "Match", "Mismatch"),
                             levels = c("Match", "Mismatch"))
  )
dat_hr  <- filter(dat, Rater == "HR")
dat_gpt <- filter(dat, Rater == "GPT")

gls_res_sd <- function(g) {
  s <- sigma(g) * c(1, coef(g$modelStruct$varStruct, unconstrained = FALSE))
  names(s)[1] <- levels(dat$Rater)[1]; round(s, 3)
}
# Within-rater model-comparison Bayes factor for ONE focal interaction term.
bf_interaction <- function(d, full_rhs, reduced_rhs) {
  d <- as.data.frame(d)
  lmBF(as.formula(paste("Suitability ~", full_rhs)),    data = d, rscaleFixed = 0.707) /
    lmBF(as.formula(paste("Suitability ~", reduced_rhs)), data = d, rscaleFixed = 0.707)
}

# =============================================================================
# H3: ApplicantAge x JobAge x Rater  (explicit factors, no composite)
#   H3a: ApplicantAge:JobAge  (mismatched rated lower than matched)
#   H3b: ApplicantAge:JobAge:Rater
# =============================================================================
cat("\n##################  H3 (explicit 3-way)  ##################\n")

# --- STEP 1. Pooled OLS ------------------------------------------------------
model_h3 <- lm(Suitability ~ ApplicantAge * JobAge * Rater, data = dat)
cat("\n=== H3 STEP 1: Model 3 (pooled OLS) ===\n")
cat("R^2 =", round(summary(model_h3)$r.squared, 3), "\n\n")
print(Anova(model_h3, type = 3))   # ApplicantAge:JobAge = H3a; :Rater = H3b
print(eta_squared(model_h3, partial = TRUE, ci = .90))

# --- STEP 2. Variance check + LRT --------------------------------------------
cat("\n=== H3 STEP 2: variance check ===\n")
gls3_equal <- gls(Suitability ~  ApplicantAge * JobAge * Rater,
                  data = dat, method = "REML")
gls3_uneq  <- gls(Suitability ~  ApplicantAge * JobAge * Rater,
                  data = dat, weights = varIdent(form = ~ 1 | Rater), method = "REML")
print(anova(gls3_equal, gls3_uneq))
cat("\n--- Residual SD by Rater ---\n"); print(gls_res_sd(gls3_uneq))

# --- STEP 3. Variance-robust focal tests (H3a, H3b) --------------------------
cat("\n=== H3 STEP 3: variance-robust gls ===\n")
print(anova(gls3_uneq, type = "marginal"))   # ApplicantAge:JobAge / :Rater are focal
cat("\n--- gls simple effects: age x jobage within each Rater ---\n")
emm3_gls <- emmeans(gls3_uneq, ~ ApplicantAge | JobAge * Rater, mode = "df.error")
print(contrast(emm3_gls, interaction = "pairwise", by = "Rater"))   # age x jobage per rater

# --- STEP 4. Per-rater models + interaction contrasts ------------------------
cat("\n=== H3 STEP 4: per-rater age x jobage ===\n")
m3_hr  <- lm(Suitability ~ ApplicantAge * JobAge, data = dat_hr)
m3_gpt <- lm(Suitability ~ ApplicantAge * JobAge, data = dat_gpt)
for (nm in c("HR", "GPT")) {
  m <- if (nm == "HR") m3_hr else m3_gpt
  cat("\n--- ", nm, " ---\n", sep = "")
  print(Anova(m, type = 3)); print(eta_squared(m, partial = TRUE, ci = .90))
  emm <- emmeans(m, ~ ApplicantAge | JobAge)
  print(emmeans(m, ~ ApplicantAge * JobAge))            # 2x2 cell means
  print(pairs(emm, adjust = "none"))                    # age within each job-age
  print(contrast(emm, interaction = "pairwise"))        # the age x jobage contrast
}

# --- STEP 5. (Optional) within-rater standardized check ----------------------

dat_z2 <- dat %>%
  group_by(Rater) %>%
  mutate(Suitability_z = as.numeric(scale(Suitability))) %>%
  ungroup()

print(Anova(
  lm(Suitability_z ~  ApplicantAge * JobAge * Rater,
     data = dat_z2),
  type = 3
))


# --- STEP 6. Bayesian (within rater, model comparison for the interaction) ---
cat("\n=== H3 STEP 6: within-rater Bayes factor for age x jobage ===\n")
set.seed(123)
bf3_hr  <- bf_interaction(dat_hr,
                          "ApplicantAge + JobAge + ApplicantAge:JobAge",
                          "ApplicantAge + JobAge")
set.seed(123)
bf3_gpt <- bf_interaction(dat_gpt,
                          "ApplicantAge + JobAge + ApplicantAge:JobAge",
                          "ApplicantAge + JobAge")
cat("HR  : BF10 =", round(as.vector(bf3_hr), 3),
    "| BF01 =", round(1/as.vector(bf3_hr), 3), "\n")
cat("GPT : BF10 =", round(as.vector(bf3_gpt), 3),
    "| BF01 =", round(1/as.vector(bf3_gpt), 3), "\n")


# =============================================================================
# H4
# =============================================================================
cat("\n##################  H4 (composite 3-way)  ##################\n")

# --- STEP 1. Pooled OLS ------------------------------------------------------
model_h4 <- lm(Suitability ~ AgeMismatch * ApplicantGender * Rater,
               data = dat)
cat("\n=== H4 STEP 1: Model 4 (pooled OLS) ===\n")
cat("R^2 =", round(summary(model_h4)$r.squared, 3), "\n\n")
print(Anova(model_h4, type = 3))   # AgeMismatch:ApplicantGender = H4a; :Rater = H4b
print(eta_squared(model_h4, partial = TRUE, ci = .90))

# --- STEP 2. Variance check + LRT --------------------------------------------
cat("\n=== H4 STEP 2: variance check ===\n")
gls4_equal <- gls(Suitability ~ AgeMismatch * ApplicantGender * Rater,
                  data = dat, method = "REML")
gls4_uneq  <- gls(Suitability ~ AgeMismatch * ApplicantGender * Rater,
                  data = dat, weights = varIdent(form = ~ 1 | Rater), method = "REML")
print(anova(gls4_equal, gls4_uneq))
cat("\n--- Residual SD by Rater ---\n"); print(gls_res_sd(gls4_uneq))

# --- STEP 3. Variance-robust focal tests (H4a, H4b) --------------------------
cat("\n=== H4 STEP 3: variance-robust gls ===\n")
print(anova(gls4_uneq, type = "marginal"))
cat("\n--- gls simple effects: mismatch x gender within each Rater ---\n")
emm4_gls <- emmeans(gls4_uneq, ~ AgeMismatch | ApplicantGender * Rater, mode = "df.error")
print(contrast(emm4_gls, interaction = "pairwise", by = "Rater"))   # mismatch x gender per rater

# --- STEP 4. Per-rater models + interaction contrasts ------------------------
cat("\n=== H4 STEP 4: per-rater mismatch x gender ===\n")
m4_hr  <- lm(Suitability ~ AgeMismatch * ApplicantGender, data = dat_hr)
m4_gpt <- lm(Suitability ~ AgeMismatch * ApplicantGender, data = dat_gpt)
for (nm in c("HR", "GPT")) {
  m <- if (nm == "HR") m4_hr else m4_gpt
  cat("\n--- ", nm, " ---\n", sep = "")
  print(Anova(m, type = 3)); print(eta_squared(m, partial = TRUE, ci = .90))
  emm <- emmeans(m, ~ AgeMismatch | ApplicantGender)
  print(emmeans(m, ~ AgeMismatch * ApplicantGender))   # 2x2 cell means
  print(pairs(emm, adjust = "none"))
  print(contrast(emm, interaction = "pairwise"))        # the H4a interaction
}

# --- STEP 5. (Optional) within-rater standardized check ----------------------

dat_z2 <- dat %>%
  group_by(Rater) %>%
  mutate(Suitability_z = as.numeric(scale(Suitability))) %>%
  ungroup()

print(Anova(
  lm(Suitability_z ~ AgeMismatch * ApplicantGender * Rater,
     data = dat_z2),
  type = 3
))

# --- STEP 6. Bayesian (within rater, model comparison for the interaction) ---
cat("\n=== H4 STEP 6: within-rater Bayes factor for mismatch x gender ===\n")
set.seed(123)
bf4_hr  <- bf_interaction(dat_hr,
                          "AgeMismatch + ApplicantGender + AgeMismatch:ApplicantGender",
                          "AgeMismatch + ApplicantGender")
set.seed(123)
bf4_gpt <- bf_interaction(dat_gpt,
                          "AgeMismatch + ApplicantGender + AgeMismatch:ApplicantGender",
                          "AgeMismatch + ApplicantGender")
cat("HR  : BF10 =", round(as.vector(bf4_hr), 3),
    "| BF01 =", round(1/as.vector(bf4_hr), 3), "\n")
cat("GPT : BF10 =", round(as.vector(bf4_gpt), 3),
    "| BF01 =", round(1/as.vector(bf4_gpt), 3), "\n")

cat("H4 HR  BF01 =", round(1 / as.vector(bf4_hr),  2), "\n")
cat("H4 GPT BF01 =", round(1 / as.vector(bf4_gpt), 2), "\n")

  )
