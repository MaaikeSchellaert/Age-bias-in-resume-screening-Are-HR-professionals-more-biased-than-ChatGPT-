# ChatGPT data collection for the revised JBP manuscript
# Study 1, Study 2, and sensitivity checks
# Models: gpt-4o, gpt-4.1, and gpt-5.4
# Existing results are in Output/. Rerunning the script overwrites them.

# Packages ####
if (!require("pak")) install.packages("pak")

pkgs <- c("here", "ellmer", "readxl", "jsonlite",
          "janitor", "purrr", "furrr", "future",
          "magrittr", "dplyr", "stringr", "lubridate", "readr")

missing_pkgs <- pkgs[!pkgs %in% installed.packages()[, "Package"]]

if (length(missing_pkgs) > 0) {
  pak::pkg_install(missing_pkgs)
}

invisible(lapply(pkgs, library, character.only = TRUE))

# Parameters ####
seed        <- 8       # fixed seed for reproducibility
temperature <- 1       # default OpenAI temperature
echo        <- "none"  # suppress ellmer chat history in output
# Main model used in the revision
models      <- c(gpt4o = "gpt-4o", gpt41 = "gpt-4.1", gpt54 = "gpt-5.4")

# API key ####
apikey <- trimws(readLines(here("Input", "openai_api_key.txt"), n = 1))
if (apikey == "" || apikey == "PLEASE INSERT KEY HERE")
  stop('Insert API key in "Input/openai_api_key.txt" first')

dir.create(here("Output"), showWarnings = FALSE)
dir.create(here("Output", "raw"), recursive = TRUE, showWarnings = FALSE)

# Helper functions ####
to_score <- function(x) {
  parse_number(x, na = c("", "NA")) %>% pmin(100) %>% pmax(1)
}

extract_df <- function(out, colname) {
  map2_dfr(out$results, seq_along(out$results), function(res, i) {
    cid    <- pluck(res, "custom_id", .default = NA_character_)
    id_num <- parse_number(cid)      # pulls row number from strings like "age-0042"
    if (is.na(id_num)) id_num <- i   # fallback: use position in the list
    tibble(
      id = as.integer(id_num),
      !!colname := pluck(res, "body", "choices", 1, "message", "content",
                         .default = NA_character_)
    )
  }) %>% distinct(id, .keep_all = TRUE)
}

# Keep the gpt-5.4 reasoning default so temperature can be set.
make_chat <- function(model, sysprompt, temp = temperature) {
  chat_openai(
    system_prompt = sysprompt,
    model = model,
    params = params(temperature = temp, seed = seed),
    echo = echo,
    api_key = apikey
  )
}

run_batch <- function(model, sysprompt, prompt_list, output_file, temp = temperature, wait = TRUE) {
  chat <- make_chat(model, sysprompt, temp)
  batch_chat(chat, prompt_list, path = here("Output", "raw", output_file), wait = wait)
}

# Retry wrapper for within-subjects API calls
chat_call <- function(chat, prompt, max_tries = 6, base_wait = 0.8) {
  for (i in seq_len(max_tries)) {
    res <- try(chat$chat(prompt), silent = TRUE)
    if (!inherits(res, "try-error")) return(res)
    Sys.sleep((base_wait * 2^(i - 1)) + runif(1, 0, 0.4))
  }
  NA_character_
}

# One shuffled recruiter session per chat_id
run_session <- function(df, model, sysprompt) {
  chat <- make_chat(model, sysprompt)
  df2  <- df %>% slice_sample(n = nrow(df))
  out  <- map(df2$prompt, ~ safely(~ chat_call(chat, .x), otherwise = NA_character_)(.x))

  tibble(
    profile_id = df2$profile_id,
    chat_id    = df2$chat_id,
    order      = seq_len(nrow(df2)),
    prompt     = df2$prompt,
    result     = map_chr(out, "result"),
    error      = map_chr(out, ~ if (is.null(.x$error)) NA_character_ else as.character(.x$error))
  )
}

# Run sessions in parallel
results_within <- function(model, sysprompt, prompt_tibble, workers = 2) {
  old_plan <- future::plan()
  on.exit(future::plan(old_plan), add = TRUE)
  future::plan(multisession, workers = workers)

  prompt_tibble %>%
    group_split(chat_id, .keep = TRUE) %>%
    future_map_dfr(run_session,
                   model = model,
                   sysprompt = sysprompt,
                   .options = furrr_options(seed = TRUE, scheduling = 1))
}

# Standardise the three numbered language columns after clean_names().
fix_taalvaardigheid <- function(df) {
  lang_cols <- grep("^taalvaardigheid_\\d+$", names(df), value = TRUE)
  stopifnot(length(lang_cols) == 3)
  df %>% rename(
    taalvaardigheid_nl = !!lang_cols[1],
    taalvaardigheid_fr = !!lang_cols[2],
    taalvaardigheid_en = !!lang_cols[3]
  )
}

# Prompt builders ####
# Standard CV prompt — between-subjects (Study 1, temperature and prompt sensitivity)
build_prompts <- function(df) {
  interpolate(
    "Jobtitel: {{jobtitel_job}}.\n Jobomschrijving: {{jobomschrijving}}\n\n
 Curriculum Vitae\n Voornaam: {{voornaam}}\n Familienaam: {{familienaam}}\n
 Geboortedatum: {{datum}}\n Geslacht: {{geslacht}}\n E-mailadres: {{email}}\n
 Rijbewijs: {{rijbewijs}}\n Functietitel: {{jobtitel_profiel}}\n
 Relevante werkervaring: {{ervaring}}\n Opleiding: {{opleiding}},
 Taalvaardigheid: {{taal_nl}}, {{taal_fr}} {{taal_en}}\n
 MS Office vaardigheid: {{office}}",
    jobtitel_job     = df$jobtitel_job,
    jobtitel_profiel = df$jobtitel_profiel,
    jobomschrijving  = df$jobomschrijving,
    voornaam         = df$voornaam,
    familienaam      = df$familienaam,
    datum            = df$geboortedatum,
    geslacht         = df$geslacht,
    email            = df$emailadres,
    rijbewijs        = df$rijbewijs,
    ervaring         = df$relevante_werkervaring,
    opleiding        = df$opleiding,
    taal_nl          = df$taalvaardigheid_nl,
    taal_fr          = df$taalvaardigheid_fr,
    taal_en          = df$taalvaardigheid_en,
    office           = df$ms_office_vaardigheden
  )
}

# Standard CV prompt — within-subjects; wraps in a tibble with session IDs
build_prompts_w <- function(df) {
  tibble::tibble(
    profile_id = df$profiel_id,
    chat_id    = df$chat_id,
    prompt     = as.character(
      interpolate(
        "Jobtitel: {{jobtitel_job}}.\n Jobomschrijving: {{jobomschrijving}}\n\n
 Curriculum Vitae\n Voornaam: {{voornaam}}\n Familienaam: {{familienaam}}\n
 Geboortedatum: {{datum}}\n Geslacht: {{geslacht}}\n E-mailadres: {{email}}\n
 Rijbewijs: {{rijbewijs}}\n Functietitel: {{jobtitel_profiel}}\n
 Relevante werkervaring: {{ervaring}}\n Opleiding: {{opleiding}},
 Taalvaardigheid: {{taal_nl}}, {{taal_fr}} {{taal_en}}\n
 MS Office vaardigheid: {{office}}",
        jobtitel_job     = df$jobtitel_job,
        jobtitel_profiel = df$jobtitel_profiel,
        jobomschrijving  = df$jobomschrijving,
        voornaam         = df$voornaam,
        familienaam      = df$familienaam,
        datum            = df$geboortedatum,
        geslacht         = df$geslacht,
        email            = df$emailadres,
        rijbewijs        = df$rijbewijs,
        ervaring         = df$relevante_werkervaring,
        opleiding        = df$opleiding,
        taal_nl          = df$taalvaardigheid_nl,
        taal_fr          = df$taalvaardigheid_fr,
        taal_en          = df$taalvaardigheid_en,
        office           = df$ms_office_vaardigheden
      )
    )
  )
}

# Prompt with additional work experience
build_prompts_exp <- function(df) {
  interpolate(
    "Jobtitel: {{jobtitel_job}}.\n Jobomschrijving: {{jobomschrijving}}\n\n
 Curriculum Vitae\n Voornaam: {{voornaam}}\n Familienaam: {{familienaam}}\n
 Geboortedatum: {{datum}}\n Geslacht: {{geslacht}}\n E-mailadres: {{email}}\n
 Rijbewijs: {{rijbewijs}}\n Functietitel: {{jobtitel_profiel}}\n
 Relevante werkervaring: {{ervaring}}\n
 Andere werkervaring: {{andere_wer}}\n
 Opleiding: {{opleiding}},
 Taalvaardigheid: {{taal_nl}}, {{taal_fr}} {{taal_en}}\n
 MS Office vaardigheid: {{office}}",
    jobtitel_job     = df$jobtitel_job,
    jobtitel_profiel = df$jobtitel_profiel,
    jobomschrijving  = df$jobomschrijving,
    voornaam         = df$voornaam,
    familienaam      = df$familienaam,
    datum            = df$geboortedatum,
    geslacht         = df$geslacht,
    email            = df$emailadres,
    rijbewijs        = df$rijbewijs,
    ervaring         = df$relevante_werkervaring,
    andere_wer       = df$andere_werkervaring,
    opleiding        = df$opleiding,
    taal_nl          = df$taalvaardigheid_nl,
    taal_fr          = df$taalvaardigheid_fr,
    taal_en          = df$taalvaardigheid_en,
    office           = df$ms_office_vaardigheden
  )
}

# Shared inputs ####
jobs_orig <-
  read_xlsx(here("Input", "chatgpt-jobs.xlsx")) %>%
  clean_names() %>%
  mutate(jobtitel = str_to_title(jobtitel)) %>%
  rename(jobtitel_job = jobtitel)

profiles_orig_b <-
  read_xlsx(here("Input", "chatgpt-profiles_study1_between.xlsx")) %>%
  clean_names() %>%
  fix_taalvaardigheid() %>%
  rename(jobtitel_profiel = jobtitel)

profiles_orig_w <-
  read_xlsx(here("Input", "chatgpt-profiles_study1_within.xlsx")) %>%
  clean_names() %>%
  fix_taalvaardigheid() %>%
  rename(jobtitel_profiel = jobtitel)

input_orig_b <- left_join(profiles_orig_b, jobs_orig, by = "job_id")
input_orig_w <- left_join(profiles_orig_w, jobs_orig, by = "job_id")

sysprompt_orig <-
  "Je helpt bij het nemen van beslissingen over personeelsselectie. Beoordeel op basis van onderstaande functietitel en -omschrijving hoe geschikt deze kandidaat is. Geef alleen een score van 1 (zeer ongeschikt) tot 100 (zeer geschikt). Geef geen verdere uitleg."

prompts_orig_b <- build_prompts(input_orig_b)
prompts_orig_w <- build_prompts_w(input_orig_w)

# Study 1: clearly qualified applicants (between-subjects) ####

# Submit first, then collect
for (m in names(models)) {
  run_batch(models[[m]], sysprompt_orig, prompts_orig_b,
            paste0("age-gpt_orig_", m, ".json"), wait = FALSE)
}
for (m in names(models)) {
  run_batch(models[[m]], sysprompt_orig, prompts_orig_b,
            paste0("age-gpt_orig_", m, ".json"))
}

out4o_orig <- read_json(here("Output", "raw", "age-gpt_orig_gpt4o.json"))
out41_orig <- read_json(here("Output", "raw", "age-gpt_orig_gpt41.json"))
out5_orig  <- read_json(here("Output", "raw", "age-gpt_orig_gpt54.json"))

df4o_orig <- extract_df(out4o_orig, "gpt4o")
df41_orig <- extract_df(out41_orig, "gpt41")
df5_orig  <- extract_df(out5_orig,  "gpt54")

responses_orig <- reduce(list(df4o_orig, df41_orig, df5_orig), full_join, by = "id") %>%
  arrange(id)

stopifnot(nrow(responses_orig) == nrow(input_orig_b))

# Age group from conditie
data_orig_b <-
  input_orig_b %>%
  mutate(
    gpt4o = to_score(responses_orig$gpt4o),
    gpt41 = to_score(responses_orig$gpt41),
    gpt54 = to_score(responses_orig$gpt54),
    leeftijd   = factor(if_else(str_detect(conditie, "AgeOld"), "Oud", "Jong")),
    leeftijd_c = time_length(interval(ymd(geboortedatum), today(tzone = "Europe/Brussels")), "years")
  ) %>%
  rename(leeftijdstype = age_type) %>%
  mutate(across(c(leeftijd, leeftijdstype, geslacht, voornaam, familienaam), factor)) %>%
  relocate(leeftijd, leeftijd_c, .after = geboortedatum) %>%
  relocate(leeftijdstype, .after = jobomschrijving)

write_csv(data_orig_b, here("Output", "study1_clearly-qualified_between.csv"))

# Study 1: within-subjects supplement ####
set.seed(seed)

d1_within4o <- results_within(models[["gpt4o"]], sysprompt_orig, prompts_orig_w)
d1_within41 <- results_within(models[["gpt41"]], sysprompt_orig, prompts_orig_w)
d1_within5  <- results_within(models[["gpt54"]], sysprompt_orig, prompts_orig_w, workers = 4)

d1_within4o <- d1_within4o %>% rename_with(~ paste0("gpt4o_", .x), c("order", "prompt", "result", "error"))
d1_within41 <- d1_within41 %>% rename_with(~ paste0("gpt41_", .x), c("order", "prompt", "result", "error"))
d1_within5  <- d1_within5  %>% rename_with(~ paste0("gpt54_", .x), c("order", "prompt", "result", "error"))

saveRDS(d1_within4o, here("Output", "raw", "age-gpt_orig_within_gpt4o-chats.rds"))
saveRDS(d1_within41, here("Output", "raw", "age-gpt_orig_within_gpt41-chats.rds"))
saveRDS(d1_within5,  here("Output", "raw", "age-gpt_orig_within_gpt54-chats.rds"))

data_orig_w <-
  input_orig_w %>%
  left_join(d1_within4o, by = join_by(profiel_id == profile_id, chat_id)) %>%
  left_join(d1_within41, by = join_by(profiel_id == profile_id, chat_id)) %>%
  left_join(d1_within5,  by = join_by(profiel_id == profile_id, chat_id)) %>%
  mutate(
    across(c(gpt4o_result, gpt41_result, gpt54_result), to_score),
    leeftijd   = factor(if_else(str_detect(conditie, "AgeOld"), "Oud", "Jong")),
    leeftijd_c = time_length(interval(ymd(geboortedatum), today(tzone = "Europe/Brussels")), "years")
  ) %>%
  rename(leeftijdstype = age_type) %>%
  mutate(across(c(leeftijd, leeftijdstype, geslacht, voornaam, familienaam), factor)) %>%
  relocate(leeftijd, leeftijd_c, .after = geboortedatum) %>%
  relocate(leeftijdstype, .after = jobomschrijving)

write_csv(data_orig_w, here("Output", "study1_within_supplement.csv"))

# Study 2: ambiguously qualified applicants (between-subjects) ####
profiles_ambigu <-
  read_xlsx(here("Input", "chatgpt-profiles_study2_ambiguous.xlsx")) %>%
  clean_names() %>%
  fix_taalvaardigheid() %>%
  rename(jobtitel_profiel = jobtitel)

input_ambigu   <- left_join(profiles_ambigu, jobs_orig, by = "job_id")
prompts_ambigu <- build_prompts_exp(input_ambigu)

for (m in names(models)) {
  run_batch(models[[m]], sysprompt_orig, prompts_ambigu,
            paste0("age-gpt_ambigu_", m, ".json"), wait = FALSE)
}
for (m in names(models)) {
  run_batch(models[[m]], sysprompt_orig, prompts_ambigu,
            paste0("age-gpt_ambigu_", m, ".json"))
}

out4o_ambigu <- read_json(here("Output", "raw", "age-gpt_ambigu_gpt4o.json"))
out41_ambigu <- read_json(here("Output", "raw", "age-gpt_ambigu_gpt41.json"))
out5_ambigu  <- read_json(here("Output", "raw", "age-gpt_ambigu_gpt54.json"))

df4o_ambigu <- extract_df(out4o_ambigu, "gpt4o")
df41_ambigu <- extract_df(out41_ambigu, "gpt41")
df5_ambigu  <- extract_df(out5_ambigu,  "gpt54")

responses_ambigu <- reduce(list(df4o_ambigu, df41_ambigu, df5_ambigu), full_join, by = "id") %>%
  arrange(id)

stopifnot(nrow(responses_ambigu) == nrow(input_ambigu))

data_ambigu <-
  input_ambigu %>%
  mutate(
    gpt4o = to_score(responses_ambigu$gpt4o),
    gpt41 = to_score(responses_ambigu$gpt41),
    gpt54 = to_score(responses_ambigu$gpt54),
    leeftijd   = factor(if_else(str_detect(conditie, "AgeOld"), "Oud", "Jong")),
    leeftijd_c = time_length(interval(ymd(geboortedatum), today(tzone = "Europe/Brussels")), "years")
  ) %>%
  rename(leeftijdstype = age_type) %>%
  mutate(across(c(leeftijd, leeftijdstype, geslacht, voornaam, familienaam), factor)) %>%
  relocate(leeftijd, leeftijd_c, .after = geboortedatum) %>%
  relocate(leeftijdstype, .after = jobomschrijving)

write_csv(data_ambigu, here("Output", "study2_ambiguous_between.csv"))

# Sensitivity check: work experience ####
profiles_exp <-
  read_xlsx(here("Input", "chatgpt-profiles_sensitivity_experience.xlsx")) %>%
  clean_names() %>%
  fix_taalvaardigheid() %>%
  rename(jobtitel_profiel = jobtitel)

input_exp   <- left_join(profiles_exp, jobs_orig, by = "job_id")
prompts_exp <- build_prompts_exp(input_exp)

for (m in names(models)) {
  run_batch(models[[m]], sysprompt_orig, prompts_exp,
            paste0("age-gpt_exp_", m, ".json"), wait = FALSE)
}
for (m in names(models)) {
  run_batch(models[[m]], sysprompt_orig, prompts_exp,
            paste0("age-gpt_exp_", m, ".json"))
}

out4o_exp <- read_json(here("Output", "raw", "age-gpt_exp_gpt4o.json"))
out41_exp <- read_json(here("Output", "raw", "age-gpt_exp_gpt41.json"))
out5_exp  <- read_json(here("Output", "raw", "age-gpt_exp_gpt54.json"))

df4o_exp <- extract_df(out4o_exp, "gpt4o")
df41_exp <- extract_df(out41_exp, "gpt41")
df5_exp  <- extract_df(out5_exp,  "gpt54")

responses_exp <- reduce(list(df4o_exp, df41_exp, df5_exp), full_join, by = "id") %>%
  arrange(id)

stopifnot(nrow(responses_exp) == nrow(input_exp))

data_exp <-
  input_exp %>%
  mutate(
    gpt4o = to_score(responses_exp$gpt4o),
    gpt41 = to_score(responses_exp$gpt41),
    gpt54 = to_score(responses_exp$gpt54),
    leeftijd   = factor(if_else(str_detect(conditie, "AgeOld"), "Oud", "Jong")),
    leeftijd_c = time_length(interval(ymd(geboortedatum), today(tzone = "Europe/Brussels")), "years")
  ) %>%
  rename(leeftijdstype = age_type) %>%
  mutate(across(c(leeftijd, leeftijdstype, geslacht, voornaam, familienaam), factor)) %>%
  relocate(leeftijd, leeftijd_c, .after = geboortedatum) %>%
  relocate(leeftijdstype, .after = jobomschrijving)

write_csv(data_exp, here("Output", "sensitivity_work-experience.csv"))

# Sensitivity check: temperature ####
temps <- c(temp0 = 0, temp05 = 0.5, temp1 = 1)

for (t_name in names(temps)) {
  for (m in names(models)) {
    run_batch(models[[m]], sysprompt_orig, prompts_orig_b,
              paste0("age-gpt_", t_name, "_", m, ".json"),
              temp = temps[[t_name]], wait = FALSE)
  }
}
for (t_name in names(temps)) {
  for (m in names(models)) {
    run_batch(models[[m]], sysprompt_orig, prompts_orig_b,
              paste0("age-gpt_", t_name, "_", m, ".json"),
              temp = temps[[t_name]])
  }
}

data_temperature <- map_dfr(names(temps), function(t_name) {
  out4o <- read_json(here("Output", "raw", paste0("age-gpt_", t_name, "_gpt4o.json")))
  out41 <- read_json(here("Output", "raw", paste0("age-gpt_", t_name, "_gpt41.json")))
  out5  <- read_json(here("Output", "raw", paste0("age-gpt_", t_name, "_gpt54.json")))

  df4o <- extract_df(out4o, "gpt4o")
  df41 <- extract_df(out41, "gpt41")
  df5  <- extract_df(out5,  "gpt54")

  responses <- reduce(list(df4o, df41, df5), full_join, by = "id") %>% arrange(id)
  stopifnot(nrow(responses) == nrow(input_orig_b))

  input_orig_b %>%
    mutate(
      temperature_val = temps[[t_name]],
      gpt4o = to_score(responses$gpt4o),
      gpt41 = to_score(responses$gpt41),
      gpt54 = to_score(responses$gpt54),
      leeftijd   = factor(if_else(str_detect(conditie, "AgeOld"), "Oud", "Jong")),
      leeftijd_c = time_length(interval(ymd(geboortedatum), today(tzone = "Europe/Brussels")), "years")
    ) %>%
    rename(leeftijdstype = age_type) %>%
    mutate(across(c(leeftijd, leeftijdstype, geslacht, voornaam, familienaam), factor)) %>%
    relocate(leeftijd, leeftijd_c, .after = geboortedatum) %>%
    relocate(leeftijdstype, .after = jobomschrijving) %>%
    relocate(temperature_val, .before = everything())
})

write_csv(data_temperature, here("Output", "sensitivity_temperature.csv"))

# Sensitivity check: prompt/role variants ####
sysprompts_roles <- list(
  hr = paste0(
    "Je bent een HR-professional met ervaring in het beoordelen van cv's. ",
    "Je helpt bij het nemen van beslissingen over personeelsselectie. ",
    "Beoordeel op basis van onderstaande functietitel en -omschrijving hoe geschikt deze kandidaat is. ",
    "Geef alleen een score van 1 (zeer ongeschikt) tot 100 (zeer geschikt). ",
    "Geef geen verdere uitleg."
  ),
  # Original prompt without the "no further explanation" instruction
  no_restrict = paste0(
    "Je helpt bij het nemen van beslissingen over personeelsselectie. ",
    "Beoordeel op basis van onderstaande functietitel en -omschrijving hoe geschikt deze kandidaat is. ",
    "Geef alleen een score van 1 (zeer ongeschikt) tot 100 (zeer geschikt)."
  ),
  # Original prompt with an added strictness instruction to counter score inflation
  strict = paste0(
    "Je helpt bij het nemen van beslissingen over personeelsselectie. ",
    "Beoordeel op basis van onderstaande functietitel en -omschrijving hoe geschikt deze kandidaat is. ",
    "Geef alleen een score van 1 (zeer ongeschikt) tot 100 (zeer geschikt). ",
    "Geef geen verdere uitleg. Gelieve streng te zijn."
  )
)

for (role in names(sysprompts_roles)) {
  for (m in names(models)) {
    run_batch(models[[m]], sysprompts_roles[[role]], prompts_orig_b,
              paste0("age-gpt_role-", role, "_", m, ".json"), wait = FALSE)
  }
}
for (role in names(sysprompts_roles)) {
  for (m in names(models)) {
    run_batch(models[[m]], sysprompts_roles[[role]], prompts_orig_b,
              paste0("age-gpt_role-", role, "_", m, ".json"))
  }
}

data_roles <- map_dfr(names(sysprompts_roles), function(role) {
  out4o <- read_json(here("Output", "raw", paste0("age-gpt_role-", role, "_gpt4o.json")))
  out41 <- read_json(here("Output", "raw", paste0("age-gpt_role-", role, "_gpt41.json")))
  out5  <- read_json(here("Output", "raw", paste0("age-gpt_role-", role, "_gpt54.json")))

  df4o <- extract_df(out4o, "gpt4o")
  df41 <- extract_df(out41, "gpt41")
  df5  <- extract_df(out5,  "gpt54")

  responses <- reduce(list(df4o, df41, df5), full_join, by = "id") %>% arrange(id)
  stopifnot(nrow(responses) == nrow(input_orig_b))

  input_orig_b %>%
    mutate(
      role_condition = role,
      gpt4o = to_score(responses$gpt4o),
      gpt41 = to_score(responses$gpt41),
      gpt54 = to_score(responses$gpt54),
      leeftijd   = factor(if_else(str_detect(conditie, "AgeOld"), "Oud", "Jong")),
      leeftijd_c = time_length(interval(ymd(geboortedatum), today(tzone = "Europe/Brussels")), "years")
    ) %>%
    rename(leeftijdstype = age_type) %>%
    mutate(across(c(leeftijd, leeftijdstype, geslacht, voornaam, familienaam), factor)) %>%
    relocate(leeftijd, leeftijd_c, .after = geboortedatum) %>%
    relocate(leeftijdstype, .after = jobomschrijving) %>%
    relocate(role_condition, .before = everything())
})

# Re-parse verbose no_restrict responses from gpt-4o and gpt-4.1
smart_score <- function(text) {
  if (is.na(text) || nchar(trimws(text)) == 0)
    return(list(score = NA_integer_, label = "na"))

  trimmed <- trimws(text)
  if (grepl("^\\d{1,3}$", trimmed)) {
    val <- as.integer(trimmed)
    return(list(score = pmin(pmax(val, 1L), 100L), label = "pure"))
  }

  m2 <- regmatches(text, regexpr("(?i)score\\s*:?\\s*(\\d{1,3})", text, perl = TRUE))
  if (length(m2) > 0 && nchar(m2) > 0) {
    val <- as.integer(regmatches(m2, regexpr("\\d{1,3}", m2)))
    if (!is.na(val) && val >= 1 && val <= 100)
      return(list(score = val, label = "score_pattern"))
  }

  all_nums <- as.integer(unlist(regmatches(text, gregexpr("\\b\\d{1,3}\\b", text))))
  in_range <- all_nums[!is.na(all_nums) & all_nums >= 1 & all_nums <= 100]
  if (length(in_range) > 0)
    return(list(score = tail(in_range, 1L), label = "last_in_range"))

  m4 <- regmatches(text, regexpr("\\d+", text))
  if (length(m4) > 0 && nchar(m4) > 0) {
    val <- pmin(pmax(as.integer(m4), 1L), 100L)
    return(list(score = val, label = "first_clamped"))
  }

  list(score = NA_integer_, label = "na")
}

load_raw_text <- function(json_path) {
  raw <- read_json(json_path)
  vapply(
    raw$results,
    \(r) pluck(r, "body", "choices", 1, "message", "content", .default = NA_character_),
    character(1)
  )
}

reparse_scores <- function(json_path) {
  parsed <- lapply(load_raw_text(json_path), smart_score)
  list(
    scores = vapply(parsed, `[[`, integer(1),   "score"),
    labels = vapply(parsed, `[[`, character(1), "label")
  )
}

nr_idx <- which(data_roles$role_condition == "no_restrict")
stopifnot(length(nr_idx) == 1600)

res4o <- reparse_scores(here("Output", "raw", "age-gpt_role-no_restrict_gpt4o.json"))
res41 <- reparse_scores(here("Output", "raw", "age-gpt_role-no_restrict_gpt41.json"))

data_roles$gpt4o[nr_idx]     <- res4o$scores
data_roles$gpt4o_extractor   <- NA_character_
data_roles$gpt4o_extractor[nr_idx] <- res4o$labels

data_roles$gpt41[nr_idx]     <- res41$scores
data_roles$gpt41_extractor   <- NA_character_
data_roles$gpt41_extractor[nr_idx] <- res41$labels

write_csv(data_roles, here("Output", "sensitivity_prompts.csv"))
