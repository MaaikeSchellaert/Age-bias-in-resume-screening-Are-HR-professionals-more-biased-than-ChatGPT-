ChatGPT data collection - "Age discrimination in resume screening" (JBP revision R1)
====================================================================================

This package contains the ChatGPT data collection for the revised manuscript: the
updated GPT-5.4 ratings for Study 1 (clearly qualified applicants), Study 2
(ambiguously qualified applicants), and the sensitivity checks. It corresponds to
the "Data_ChatGPT" component of the OSF project.

Models called: gpt-4o and gpt-4.1 (exploratory) and gpt-5.4 (main results).
Parameters: seed = 8, temperature = 1 (except where varied in the temperature check).

------------------------------------------------------------------------------------
How to reproduce
------------------------------------------------------------------------------------
1. Open chatgpt-age_revised.Rproj in your preferred R IDE.
2. Open Code/chatgpt-age_revised.R.
3. Create Input/openai_api_key.txt and insert a valid API key
   (https://platform.openai.com/api-keys). Do not share this file.
4. Run Code/chatgpt-age_revised.R.

The already-collected data are provided in Output/ (raw API responses in
Output/raw/). Re-running the script calls the OpenAI API and overwrites these files.
ChatGPT ratings are not perfectly deterministic, so re-collected values may differ
slightly from the shipped data.

------------------------------------------------------------------------------------
What maps to what (paper element -> Output file)
------------------------------------------------------------------------------------
Study 1  (clearly qualified, between-subjects)  ->  Output/study1_clearly-qualified_between.csv
Study 1  (within-subjects, online supplement)   ->  Output/study1_within_supplement.csv
Study 2  (ambiguous, between-subjects)          ->  Output/study2_ambiguous_between.csv
Sensitivity: adapted work experience            ->  Output/sensitivity_work-experience.csv
Sensitivity: temperature (0 / 0.5 / 1)          ->  Output/sensitivity_temperature.csv
Sensitivity: prompt/role variants               ->  Output/sensitivity_prompts.csv

Prompt/role variants (role_condition column): hr = HR-professional role instruction;
no_restrict = without the "no further explanation" instruction; strict = with an
added strictness instruction. The no_restrict gpt-4o/gpt-4.1 scores are re-extracted
from the raw responses (verbose replies break simple number parsing); the extractor
used per row is recorded in the gpt4o_extractor / gpt41_extractor columns.

Input/ files:
  chatgpt-jobs.xlsx                             job titles and descriptions
  chatgpt-profiles_study1_between.xlsx          Study 1 profiles (also used for the temperature and prompt checks)
  chatgpt-profiles_study1_within.xlsx           Study 1 within-subjects profiles with chat session IDs
  chatgpt-profiles_study2_ambiguous.xlsx        Study 2 ambiguous profiles (mismatched degree)
  chatgpt-profiles_sensitivity_experience.xlsx  work-experience sensitivity profiles

------------------------------------------------------------------------------------
Key variables (Output CSVs)
------------------------------------------------------------------------------------
leeftijd              applicant age group: Jong (young) / Oud (old)
leeftijd_c            continuous age in years (from geboortedatum)
leeftijdstype         job age-type manipulation
geslacht              applicant gender
gpt4o, gpt41, gpt54   suitability scores (1-100) from each model
                      (within file: gpt4o_result / gpt41_result / gpt54_result;
                       chat_id identifies the chat session)
role_condition        (prompts file only) system-prompt variant
temperature_val       (temperature file only) temperature setting
